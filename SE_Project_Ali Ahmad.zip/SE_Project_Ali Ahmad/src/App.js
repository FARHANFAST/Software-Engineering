import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import HomePage from './components/Home/HomePage';
import SellerDashboard from './components/SellerDashboard/SellerDashboard';
import AdminDashboard from './components/AdminDashboard/AdminDashboard';
import { SellerProvider } from './context/SellerContext';
import { AdminProvider } from './context/AdminContext';
import { AuthProvider } from './context/AuthContext';
import 'react-toastify/dist/ReactToastify.css';
import './styles.css';

function App() {
  return (
    <Router>
      <AuthProvider>
        <AdminProvider>
          <SellerProvider>
            <div className="app">
              <Navbar />
              <main className="main-content min-h-screen bg-gray-50">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  {/* Development Routes - No Auth Required */}
                  <Route path="/seller/*" element={<SellerDashboard />} />
                  <Route path="/admin/*" element={<AdminDashboard />} />
                </Routes>
              </main>
              <Footer />
              <ToastContainer
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
              />
            </div>
          </SellerProvider>
        </AdminProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
