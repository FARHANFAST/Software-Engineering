import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

function Header() {
  return (
    <header className="header">
      <div className="header__logo">
        <Link to="/">Amazon Clone</Link>
      </div>
      <nav className="header__nav">
        <Link to="/orders">Orders</Link>
        <Link to="/checkout">Checkout</Link>
        <Link to="/shipping">Shipping</Link>
      </nav>
    </header>
  );
}

export default Header; 