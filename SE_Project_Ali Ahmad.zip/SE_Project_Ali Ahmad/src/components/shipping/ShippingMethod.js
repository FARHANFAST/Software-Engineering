import React, { useState } from 'react';
import './ShippingMethod.css';

function ShippingMethod() {
  const [selectedMethod, setSelectedMethod] = useState('');

  const shippingMethods = [
    {
      id: 'standard',
      name: 'Standard Delivery',
      description: '5-7 business days',
      price: 'Free',
      icon: '🚚'
    },
    {
      id: 'express',
      name: 'Express Delivery',
      description: '2-3 business days',
      price: '$9.99',
      icon: '⚡'
    }
  ];

  return (
    <div className="shipping-method">
      <h2>Select Shipping Method</h2>
      <div className="shipping-options">
        {shippingMethods.map(method => (
          <div
            key={method.id}
            className={`shipping-option ${selectedMethod === method.id ? 'selected' : ''}`}
            onClick={() => setSelectedMethod(method.id)}
          >
            <span className="option-icon">{method.icon}</span>
            <div className="option-details">
              <h3>{method.name}</h3>
              <p>{method.description}</p>
              <p className="price">{method.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ShippingMethod; 