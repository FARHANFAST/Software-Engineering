import React, { useState } from 'react';
import './PaymentOptions.css';

function PaymentOptions() {
  const [selectedMethod, setSelectedMethod] = useState('card');

  const paymentMethods = [
    {
      id: 'card',
      name: 'Credit/Debit Card',
      icon: '💳',
      description: 'Pay with your card'
    },
    {
      id: 'cod',
      name: 'Cash on Delivery',
      icon: '💵',
      description: 'Pay when you receive'
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: '🔵',
      description: 'Pay with PayPal'
    },
    {
      id: 'gpay',
      name: 'Google Pay',
      icon: '📱',
      description: 'Pay with Google Pay'
    },
    {
      id: 'applepay',
      name: 'Apple Pay',
      icon: '🍎',
      description: 'Pay with Apple Pay'
    }
  ];

  return (
    <div className="payment-options">
      <h3>Payment Method</h3>
      <div className="payment-methods">
        {paymentMethods.map(method => (
          <div 
            key={method.id}
            className={`payment-option ${selectedMethod === method.id ? 'selected' : ''}`}
            onClick={() => setSelectedMethod(method.id)}
          >
            <input
              type="radio"
              id={method.id}
              name="paymentMethod"
              value={method.id}
              checked={selectedMethod === method.id}
              onChange={() => setSelectedMethod(method.id)}
            />
            <label htmlFor={method.id}>
              <div className="option-details">
                <span className="payment-icon">{method.icon}</span>
                <div className="payment-info">
                  <h4>{method.name}</h4>
                  <p>{method.description}</p>
                </div>
              </div>
            </label>
          </div>
        ))}
      </div>

      {selectedMethod === 'card' && (
        <div className="card-details">
          <div className="form-group">
            <label>Card Number</label>
            <input type="text" placeholder="1234 5678 9012 3456" />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Expiry Date</label>
              <input type="text" placeholder="MM/YY" />
            </div>
            <div className="form-group">
              <label>CVV</label>
              <input type="text" placeholder="123" />
            </div>
          </div>
          <div className="form-group">
            <label>Name on Card</label>
            <input type="text" placeholder="John Doe" />
          </div>
        </div>
      )}
    </div>
  );
}

export default PaymentOptions; 