import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import './Invoice.css';

function Invoice() {
  const { orderId } = useParams();
  // This will be replaced with actual data from your MySQL database
  const [order] = useState({
    id: orderId,
    date: '2024-03-21',
    items: [
      {
        id: 1,
        name: 'Product 1',
        price: 49.99,
        quantity: 2,
        image: 'https://via.placeholder.com/100'
      },
      {
        id: 2,
        name: 'Product 2',
        price: 29.99,
        quantity: 1,
        image: 'https://via.placeholder.com/100'
      }
    ],
    shippingAddress: {
      name: 'John Doe',
      street: '123 Main St',
      city: 'New York',
      state: 'NY',
      zipCode: '10001'
    },
    paymentMethod: 'Credit Card',
    shippingMethod: 'Standard Delivery',
    subtotal: 129.97,
    shipping: 0,
    tax: 13.00,
    total: 142.97,
    discount: 0
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="invoice">
      <div className="invoice-header">
        <h2>Order Confirmation</h2>
        <button onClick={handlePrint} className="print-button">
          Print Invoice
        </button>
      </div>

      <div className="invoice-content">
        <div className="invoice-section">
          <h3>Order Information</h3>
          <p>Order Number: #{order.id}</p>
          <p>Order Date: {order.date}</p>
          <p>Payment Method: {order.paymentMethod}</p>
          <p>Shipping Method: {order.shippingMethod}</p>
        </div>

        <div className="invoice-section">
          <h3>Shipping Address</h3>
          <p>{order.shippingAddress.name}</p>
          <p>{order.shippingAddress.street}</p>
          <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
        </div>

        <div className="invoice-section">
          <h3>Order Items</h3>
          <div className="items-table">
            <table>
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map(item => (
                  <tr key={item.id}>
                    <td>
                      <div className="item-info">
                        <img src={item.image} alt={item.name} />
                        <span>{item.name}</span>
                      </div>
                    </td>
                    <td>{item.quantity}</td>
                    <td>${item.price.toFixed(2)}</td>
                    <td>${(item.price * item.quantity).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="invoice-section">
          <h3>Order Summary</h3>
          <div className="summary-table">
            <table>
              <tbody>
                <tr>
                  <td>Subtotal:</td>
                  <td>${order.subtotal.toFixed(2)}</td>
                </tr>
                <tr>
                  <td>Shipping:</td>
                  <td>${order.shipping.toFixed(2)}</td>
                </tr>
                <tr>
                  <td>Tax:</td>
                  <td>${order.tax.toFixed(2)}</td>
                </tr>
                {order.discount > 0 && (
                  <tr>
                    <td>Discount:</td>
                    <td>-${order.discount.toFixed(2)}</td>
                  </tr>
                )}
                <tr className="total-row">
                  <td>Total:</td>
                  <td>${order.total.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Invoice; 