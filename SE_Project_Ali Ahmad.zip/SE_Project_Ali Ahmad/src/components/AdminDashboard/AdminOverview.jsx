import React from 'react';
import { FaUsers, FaShoppingCart, FaMoneyBillWave, FaStore } from 'react-icons/fa';

const AdminOverview = () => {
  // Sample data
  const stats = {
    totalUsers: 15420,
    totalOrders: 2845,
    totalRevenue: 458900,
    activeSellers: 126,
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-800">Dashboard Overview</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Users</p>
              <p className="text-2xl font-semibold text-gray-800">
                {stats.totalUsers.toLocaleString()}
              </p>
              <p className="text-sm text-green-600 mt-2">+12% from last month</p>
            </div>
            <FaUsers className="text-4xl text-amazon-orange opacity-80" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Orders</p>
              <p className="text-2xl font-semibold text-gray-800">
                {stats.totalOrders.toLocaleString()}
              </p>
              <p className="text-sm text-green-600 mt-2">+8% from last month</p>
            </div>
            <FaShoppingCart className="text-4xl text-amazon-orange opacity-80" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Revenue</p>
              <p className="text-2xl font-semibold text-gray-800">
                ${stats.totalRevenue.toLocaleString()}
              </p>
              <p className="text-sm text-green-600 mt-2">+15% from last month</p>
            </div>
            <FaMoneyBillWave className="text-4xl text-amazon-orange opacity-80" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Active Sellers</p>
              <p className="text-2xl font-semibold text-gray-800">
                {stats.activeSellers}
              </p>
              <p className="text-sm text-green-600 mt-2">+5% from last month</p>
            </div>
            <FaStore className="text-4xl text-amazon-orange opacity-80" />
          </div>
        </div>
      </div>

      {/* Placeholder for charts and other content */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
        <p className="text-gray-600">No recent activity to display.</p>
      </div>
    </div>
  );
};

export default AdminOverview; 