import React from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import AdminOverview from './AdminOverview';
import UserManagement from './UserManagement';
import OrderManagement from './OrderManagement';
import SalesReport from './SalesReport';

const AdminDashboard = () => {
  const location = useLocation();

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-md">
        <div className="p-4 bg-amazon-dark text-white">
          <h2 className="text-xl font-semibold">Admin Dashboard</h2>
        </div>
        <nav className="mt-4">
          <Link
            to="/admin"
            className={`block px-4 py-2 text-gray-800 hover:bg-gray-100 ${
              location.pathname === '/admin' ? 'bg-gray-100 border-l-4 border-amazon-orange' : ''
            }`}
          >
            Overview
          </Link>
          <Link
            to="/admin/users"
            className={`block px-4 py-2 text-gray-800 hover:bg-gray-100 ${
              location.pathname === '/admin/users' ? 'bg-gray-100 border-l-4 border-amazon-orange' : ''
            }`}
          >
            User Management
          </Link>
          <Link
            to="/admin/orders"
            className={`block px-4 py-2 text-gray-800 hover:bg-gray-100 ${
              location.pathname === '/admin/orders' ? 'bg-gray-100 border-l-4 border-amazon-orange' : ''
            }`}
          >
            Order Management
          </Link>
          <Link
            to="/admin/reports"
            className={`block px-4 py-2 text-gray-800 hover:bg-gray-100 ${
              location.pathname === '/admin/reports' ? 'bg-gray-100 border-l-4 border-amazon-orange' : ''
            }`}
          >
            Sales Reports
          </Link>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        <Routes>
          <Route index element={<AdminOverview />} />
          <Route path="users" element={<UserManagement />} />
          <Route path="orders" element={<OrderManagement />} />
          <Route path="reports" element={<SalesReport />} />
        </Routes>
      </div>
    </div>
  );
};

export default AdminDashboard; 