import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaSearch, FaShoppingCart, FaUserCircle, FaCaretDown } from 'react-icons/fa';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'react-toastify';

const Navbar = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
  };

  return (
    <nav className="bg-amazon-dark text-white">
      {/* Top Bar */}
      <div className="max-w-[1500px] mx-auto">
        <div className="flex items-center justify-between px-4 py-2">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img
              src="/amazon-logo.png"
              alt="Amazon Clone"
              className="h-8 mr-2"
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = 'https://via.placeholder.com/120x40?text=Amazon+Clone';
              }}
            />
          </Link>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl mx-4">
            <form onSubmit={handleSearch} className="flex">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full px-4 py-2 rounded-l-md focus:outline-none text-gray-900"
              />
              <button
                type="submit"
                className="px-6 bg-amazon-yellow hover:bg-amazon-orange text-amazon-dark rounded-r-md flex items-center"
              >
                <FaSearch />
              </button>
            </form>
          </div>

          {/* Right Section */}
          <div className="flex items-center space-x-6">
            {/* Development Links */}
            <Link to="/seller" className="text-amazon-yellow hover:text-amazon-orange">
              Seller
            </Link>
            <Link to="/admin" className="text-amazon-yellow hover:text-amazon-orange">
              Admin
            </Link>

            {/* Cart */}
            <Link to="/cart" className="flex items-center hover:text-amazon-yellow">
              <div className="relative">
                <FaShoppingCart className="text-2xl" />
                <span className="absolute -top-2 -right-2 bg-amazon-orange text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {user?.cartItems || 0}
                </span>
              </div>
              <span className="ml-1 hidden md:inline">Cart</span>
            </Link>

            {/* User Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="flex items-center hover:text-amazon-yellow"
                >
                  <FaUserCircle className="text-2xl mr-1" />
                  <span className="hidden md:inline">{user.name}</span>
                  <FaCaretDown className="ml-1" />
                </button>

                {showDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                    <Link
                      to="/profile"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Your Profile
                    </Link>
                    <Link
                      to="/orders"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Your Orders
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="flex items-center hover:text-amazon-yellow"
              >
                <FaUserCircle className="text-2xl mr-1" />
                <span>Sign In</span>
              </Link>
            )}
          </div>
        </div>

        {/* Bottom Bar - Categories */}
        <div className="bg-amazon-light px-4 py-2">
          <div className="flex items-center space-x-6 text-sm">
            <Link to="/products" className="hover:text-amazon-yellow">
              All Products
            </Link>
            <Link to="/today-deals" className="hover:text-amazon-yellow">
              Today's Deals
            </Link>
            <Link to="/customer-service" className="hover:text-amazon-yellow">
              Customer Service
            </Link>
            <Link to="/new-releases" className="hover:text-amazon-yellow">
              New Releases
            </Link>
            <Link to="/best-sellers" className="hover:text-amazon-yellow">
              Best Sellers
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 