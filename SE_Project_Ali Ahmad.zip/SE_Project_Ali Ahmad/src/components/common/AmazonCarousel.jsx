import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const AmazonCarousel = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
  };

  const banners = [
    {
      id: 1,
      image: 'https://m.media-amazon.com/images/I/61TD5JLGhIL._SX3000_.jpg',
      alt: 'Prime Day Deals',
    },
    {
      id: 2,
      image: 'https://m.media-amazon.com/images/I/71tIrZqybrL._SX3000_.jpg',
      alt: 'Electronics Sale',
    },
    {
      id: 3,
      image: 'https://m.media-amazon.com/images/I/61jovjd+f9L._SX3000_.jpg',
      alt: 'Fashion Deals',
    },
  ];

  return (
    <div className="relative">
      <Slider {...settings}>
        {banners.map((banner) => (
          <div key={banner.id} className="relative">
            <img
              src={banner.image}
              alt={banner.alt}
              className="w-full h-[300px] md:h-[400px] object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-900 to-transparent" />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default AmazonCarousel; 