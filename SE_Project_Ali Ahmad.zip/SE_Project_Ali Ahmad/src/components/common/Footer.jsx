import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-amazon-dark text-white">
      <div className="container mx-auto py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Get to Know Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Get to Know Us</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="hover:text-amazon-orange">About Us</Link></li>
              <li><Link to="/careers" className="hover:text-amazon-orange">Careers</Link></li>
              <li><Link to="/press" className="hover:text-amazon-orange">Press Releases</Link></li>
            </ul>
          </div>

          {/* Make Money with Us */}
          <div>
            <h3 className="text-lg font-bold mb-4">Make Money with Us</h3>
            <ul className="space-y-2">
              <li><Link to="/sell" className="hover:text-amazon-orange">Sell products</Link></li>
              <li><Link to="/affiliate" className="hover:text-amazon-orange">Affiliate Program</Link></li>
              <li><Link to="/advertise" className="hover:text-amazon-orange">Advertise Your Products</Link></li>
            </ul>
          </div>

          {/* Payment Products */}
          <div>
            <h3 className="text-lg font-bold mb-4">Payment Products</h3>
            <ul className="space-y-2">
              <li><Link to="/business" className="hover:text-amazon-orange">Business Card</Link></li>
              <li><Link to="/credit" className="hover:text-amazon-orange">Shop with Points</Link></li>
              <li><Link to="/reload" className="hover:text-amazon-orange">Reload Your Balance</Link></li>
            </ul>
          </div>

          {/* Let Us Help You */}
          <div>
            <h3 className="text-lg font-bold mb-4">Let Us Help You</h3>
            <ul className="space-y-2">
              <li><Link to="/account" className="hover:text-amazon-orange">Your Account</Link></li>
              <li><Link to="/orders" className="hover:text-amazon-orange">Your Orders</Link></li>
              <li><Link to="/help" className="hover:text-amazon-orange">Help Center</Link></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-gray-700 text-center">
          <p className="text-sm">&copy; {new Date().getFullYear()} Amazon Clone. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 