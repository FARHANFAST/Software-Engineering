import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  FaTachometerAlt,
  FaShoppingCart,
  FaBox,
  FaChartLine,
  FaUsers,
  FaClipboardList,
  FaChartBar,
  FaBars,
  FaTimes,
} from 'react-icons/fa';
import { useAuth } from '../../context/AuthContext';

const Sidebar = () => {
  const { isAdmin, isSeller } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const sellerMenuItems = [
    {
      path: '/seller',
      name: 'Dashboard',
      icon: <FaTachometerAlt />,
    },
    {
      path: '/seller/orders',
      name: 'Orders',
      icon: <FaShoppingCart />,
    },
    {
      path: '/seller/products',
      name: 'Products',
      icon: <FaBox />,
    },
    {
      path: '/seller/earnings',
      name: 'Earnings',
      icon: <FaChartLine />,
    },
  ];

  const adminMenuItems = [
    {
      path: '/admin',
      name: 'Dashboard',
      icon: <FaTachometerAlt />,
    },
    {
      path: '/admin/users',
      name: 'User Management',
      icon: <FaUsers />,
    },
    {
      path: '/admin/orders',
      name: 'Order Management',
      icon: <FaClipboardList />,
    },
    {
      path: '/admin/reports',
      name: 'Sales Reports',
      icon: <FaChartBar />,
    },
  ];

  const menuItems = isAdmin ? adminMenuItems : isSeller ? sellerMenuItems : [];

  const isActiveRoute = (path) => {
    return location.pathname === path;
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  if (!isAdmin && !isSeller) return null;

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={toggleMobileMenu}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-amazon-dark text-white hover:bg-amazon-light focus:outline-none"
      >
        {isMobileMenuOpen ? <FaTimes /> : <FaBars />}
      </button>

      {/* Overlay for mobile */}
      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={toggleMobileMenu}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full bg-amazon-dark text-white w-64 transform transition-transform duration-300 ease-in-out z-40
          lg:relative lg:translate-x-0
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-amazon-light">
            <h2 className="text-xl font-semibold">
              {isAdmin ? 'Admin Panel' : 'Seller Dashboard'}
            </h2>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto py-4">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`
                  flex items-center px-6 py-3 text-sm
                  ${
                    isActiveRoute(item.path)
                      ? 'bg-amazon-orange text-white'
                      : 'text-gray-300 hover:bg-amazon-light'
                  }
                  transition-colors duration-200
                `}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <span className="text-xl mr-3">{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-amazon-light">
            <div className="flex items-center text-sm text-gray-300">
              <FaTachometerAlt className="mr-2" />
              <span>
                {isAdmin ? 'Admin Version 1.0' : 'Seller Version 1.0'}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content spacer for large screens */}
      <div className="hidden lg:block w-64 flex-shrink-0" />
    </>
  );
};

export default Sidebar; 