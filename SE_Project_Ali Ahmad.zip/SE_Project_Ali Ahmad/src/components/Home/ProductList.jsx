import React from 'react';
import { Link } from 'react-router-dom';

const ProductList = ({ products }) => {
  const renderStars = (rating) => {
    const stars = [];
    for (let i = 0; i < 5; i++) {
      stars.push(
        <span key={i} style={{ color: i < rating ? '#ffa41c' : '#ccc' }}>
          ★
        </span>
      );
    }
    return stars;
  };

  return (
    <div className="product-grid" style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
      gap: '20px',
      padding: '20px 0'
    }}>
      {products.map((product) => (
        <Link
          key={product.id}
          to={`/product/${product.id}`}
          style={{ textDecoration: 'none', color: 'inherit' }}
        >
          <div className="product-card" style={{
            backgroundColor: 'white',
            padding: '15px',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            transition: 'transform 0.2s',
            cursor: 'pointer',
            ':hover': {
              transform: 'translateY(-5px)'
            }
          }}>
            <img
              src={product.image}
              alt={product.title}
              style={{
                width: '100%',
                height: 'auto',
                marginBottom: '10px'
              }}
            />
            <h3 style={{
              fontSize: '16px',
              marginBottom: '8px',
              height: '48px',
              overflow: 'hidden'
            }}>
              {product.title}
            </h3>
            <div className="rating" style={{ marginBottom: '8px' }}>
              {renderStars(product.rating)}
            </div>
            <div className="price" style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: '#B12704'
            }}>
              ${product.price.toFixed(2)}
            </div>
            <button
              className="btn-primary"
              style={{
                width: '100%',
                marginTop: '10px',
                padding: '8px',
                backgroundColor: 'var(--amazon-orange)',
                border: 'none',
                borderRadius: '4px',
                color: 'white',
                cursor: 'pointer'
              }}
            >
              Add to Cart
            </button>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default ProductList; 