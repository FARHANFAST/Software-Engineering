import React from 'react';
import AmazonCarousel from '../common/AmazonCarousel';

const HomePage = () => {
  // Sample featured products data
  const featuredProducts = [
    {
      id: 1,
      title: 'Electronics',
      image: 'https://m.media-amazon.com/images/I/61Y30DpqRVL._AC_UY218_.jpg',
      link: '/category/electronics'
    },
    {
      id: 2,
      title: 'Fashion',
      image: 'https://m.media-amazon.com/images/I/71D9ImsvEtL._AC_UL320_.jpg',
      link: '/category/fashion'
    },
    {
      id: 3,
      title: 'Home & Kitchen',
      image: 'https://m.media-amazon.com/images/I/71vnfROCeYL._AC_UL320_.jpg',
      link: '/category/home-kitchen'
    },
    {
      id: 4,
      title: 'Books',
      image: 'https://m.media-amazon.com/images/I/71aLultW5EL._AC_UY218_.jpg',
      link: '/category/books'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Hero Carousel */}
      <section className="relative">
        <AmazonCarousel />
      </section>

      {/* Featured Categories */}
      <section className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">Featured Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-48 object-cover mb-4 rounded"
              />
              <h3 className="text-lg font-semibold mb-2">{product.title}</h3>
              <a
                href={product.link}
                className="text-amazon-orange hover:text-amazon-orange-dark"
              >
                Shop now
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* Deals Section */}
      <section className="bg-white py-8">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6">Today's Deals</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-gray-100 h-48 rounded-lg animate-pulse" />
            ))}
          </div>
        </div>
      </section>

      {/* Recommendations */}
      <section className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">Recommended for You</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, index) => (
            <div key={index} className="bg-white p-4 rounded-lg shadow-sm">
              <div className="bg-gray-100 h-32 rounded-lg animate-pulse mb-2" />
              <div className="h-4 bg-gray-100 rounded animate-pulse mb-2" />
              <div className="h-4 bg-gray-100 rounded animate-pulse w-2/3" />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default HomePage; 