import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './OrderHistory.css';

function OrderHistory() {
  // This will be replaced with actual data from your MySQL database
  const [orders] = useState([
    {
      id: 1,
      date: '2024-03-21',
      total: 99.99,
      status: 'Delivered',
      items: 3
    },
    {
      id: 2,
      date: '2024-03-20',
      total: 149.99,
      status: 'Processing',
      items: 2
    }
  ]);

  return (
    <div className="order-history">
      <h2>Your Orders</h2>
      <div className="orders-list">
        {orders.map(order => (
          <div key={order.id} className="order-card">
            <div className="order-header">
              <div className="order-info">
                <p>Order #{order.id}</p>
                <p>Placed on {order.date}</p>
              </div>
              <div className="order-status">
                <span className={`status ${order.status.toLowerCase()}`}>
                  {order.status}
                </span>
              </div>
            </div>
            <div className="order-details">
              <p>{order.items} items</p>
              <p>Total: ${order.total}</p>
            </div>
            <div className="order-actions">
              <Link to={`/order/${order.id}`} className="view-details">
                View Details
              </Link>
              {order.status === 'Processing' && (
                <button className="cancel-order">Cancel Order</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default OrderHistory; 