import React from 'react';
import { useParams } from 'react-router-dom';
import './Invoice.css';

function Invoice() {
  const { orderId } = useParams();
  
  // This would typically come from an API call
  const order = {
    id: orderId,
    date: '2024-03-21',
    items: [
      {
        id: 1,
        title: 'Wireless Headphones',
        price: 99.99,
        quantity: 2,
        image: 'https://via.placeholder.com/100'
      },
      {
        id: 2,
        title: 'Smart Watch',
        price: 199.99,
        quantity: 1,
        image: 'https://via.placeholder.com/100'
      }
    ],
    shippingAddress: {
      fullName: 'John Doe',
      street: '123 Main St',
      city: 'New York',
      state: 'NY',
      zipCode: '10001'
    },
    paymentMethod: 'Credit Card',
    shippingMethod: 'Express Delivery',
    subtotal: 399.97,
    shipping: 9.99,
    total: 409.96
  };

  return (
    <div className="invoice">
      <div className="invoice-header">
        <h2>Invoice</h2>
        <div className="invoice-details">
          <p>Invoice #: {order.id}</p>
          <p>Date: {order.date}</p>
        </div>
      </div>

      <div className="invoice-content">
        <div className="shipping-info">
          <h3>Shipping Address</h3>
          <p>{order.shippingAddress.fullName}</p>
          <p>{order.shippingAddress.street}</p>
          <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
        </div>

        <div className="order-items">
          <h3>Order Items</h3>
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map(item => (
                <tr key={item.id}>
                  <td>
                    <div className="item-info">
                      <img src={item.image} alt={item.title} />
                      <span>{item.title}</span>
                    </div>
                  </td>
                  <td>${item.price.toFixed(2)}</td>
                  <td>{item.quantity}</td>
                  <td>${(item.price * item.quantity).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="payment-info">
          <h3>Payment Information</h3>
          <p>Payment Method: {order.paymentMethod}</p>
          <p>Shipping Method: {order.shippingMethod}</p>
        </div>

        <div className="invoice-summary">
          <div className="summary-item">
            <span>Subtotal:</span>
            <span>${order.subtotal.toFixed(2)}</span>
          </div>
          <div className="summary-item">
            <span>Shipping:</span>
            <span>${order.shipping.toFixed(2)}</span>
          </div>
          <div className="summary-item total">
            <span>Total:</span>
            <span>${order.total.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="invoice-footer">
        <p>Thank you for your business!</p>
        <button onClick={() => window.print()}>Print Invoice</button>
      </div>
    </div>
  );
}

export default Invoice; 