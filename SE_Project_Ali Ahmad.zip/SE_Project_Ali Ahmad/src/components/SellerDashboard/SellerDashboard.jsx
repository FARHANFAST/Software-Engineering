import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { FaBox, FaShoppingCart, FaChartLine, FaPlus, FaEdit, FaTrash } from 'react-icons/fa';
import { useSeller } from '../../context/SellerContext';
import { toast } from 'react-toastify';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const SellerDashboard = () => {
  const { sellerData } = useSeller();

  const handleAddProduct = () => {
    toast.info('Add product functionality coming soon!');
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Monthly Sales Overview',
      },
    },
  };

  const chartData = {
    labels: sellerData.monthlySales.labels,
    datasets: [
      {
        label: 'Sales ($)',
        data: sellerData.monthlySales.data,
        borderColor: '#ff9900',
        backgroundColor: '#febd69',
      },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 lg:p-8">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div className="card bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Total Earnings</p>
              <h3 className="text-2xl font-bold text-amazon-dark">
                ${sellerData.totalEarnings.toLocaleString()}
              </h3>
            </div>
            <FaChartLine className="text-4xl text-amazon-orange" />
          </div>
        </div>

        <div className="card bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Pending Orders</p>
              <h3 className="text-2xl font-bold text-amazon-dark">
                {sellerData.pendingOrders}
              </h3>
            </div>
            <FaShoppingCart className="text-4xl text-amazon-yellow" />
          </div>
        </div>

        <div className="card bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Successful Orders</p>
              <h3 className="text-2xl font-bold text-amazon-dark">
                {sellerData.successfulOrders}
              </h3>
            </div>
            <FaBox className="text-4xl text-green-500" />
          </div>
        </div>
      </div>

      {/* Sales Chart */}
      <div className="card bg-white p-6 rounded-lg shadow-md mb-8">
        <Line options={chartOptions} data={chartData} />
      </div>

      {/* Product Management */}
      <div className="card bg-white p-6 rounded-lg shadow-md mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-amazon-dark">Product Management</h2>
          <button
            onClick={handleAddProduct}
            className="btn-primary flex items-center gap-2"
          >
            <FaPlus /> Add Product
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-amazon-light text-white">
              <tr>
                <th className="py-3 px-4 text-left">Product Name</th>
                <th className="py-3 px-4 text-left">Stock</th>
                <th className="py-3 px-4 text-left">Price</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sellerData.products.map((product) => (
                <tr key={product.id}>
                  <td className="py-3 px-4">{product.name}</td>
                  <td className="py-3 px-4">{product.stock}</td>
                  <td className="py-3 px-4">${product.price}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button className="p-2 text-amazon-yellow hover:text-amazon-orange">
                        <FaEdit />
                      </button>
                      <button className="p-2 text-red-500 hover:text-red-600">
                        <FaTrash />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="card bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-bold text-amazon-dark mb-6">Recent Orders</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-amazon-light text-white">
              <tr>
                <th className="py-3 px-4 text-left">Order ID</th>
                <th className="py-3 px-4 text-left">Customer</th>
                <th className="py-3 px-4 text-left">Amount</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sellerData.recentOrders.map((order) => (
                <tr key={order.id}>
                  <td className="py-3 px-4">#{order.id}</td>
                  <td className="py-3 px-4">{order.customer}</td>
                  <td className="py-3 px-4">${order.amount}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded text-sm ${
                        order.status === 'Delivered'
                          ? 'bg-green-100 text-green-800'
                          : order.status === 'Processing'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">{order.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard; 