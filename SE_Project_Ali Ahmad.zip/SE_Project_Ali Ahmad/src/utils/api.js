import axios from 'axios';

// API configuration
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for adding auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Error handler utility
const handleApiError = (error) => {
  const errorMessage = error.response?.data?.message || 'An unexpected error occurred';
  throw new Error(errorMessage);
};

// Seller Dashboard API Functions
export const sellerApi = {
  // Dashboard Overview
  getDashboardStats: async () => {
    try {
      const response = await api.get('/seller/dashboard/stats');
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // Products Management
  getProducts: async (page = 1, limit = 10) => {
    try {
      const response = await api.get(`/seller/products?page=${page}&limit=${limit}`);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  addProduct: async (productData) => {
    try {
      const response = await api.post('/seller/products', productData);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  updateProduct: async (productId, productData) => {
    try {
      const response = await api.put(`/seller/products/${productId}`, productData);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  deleteProduct: async (productId) => {
    try {
      const response = await api.delete(`/seller/products/${productId}`);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // Orders Management
  getSellerOrders: async (status, page = 1, limit = 10) => {
    try {
      const response = await api.get(`/seller/orders?status=${status}&page=${page}&limit=${limit}`);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  updateOrderStatus: async (orderId, status) => {
    try {
      const response = await api.put(`/seller/orders/${orderId}/status`, { status });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // Sales Reports
  getSellerSalesReport: async (period = 'monthly', startDate, endDate) => {
    try {
      const response = await api.get('/seller/reports/sales', {
        params: { period, startDate, endDate },
      });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },
};

// Admin Dashboard API Functions
export const adminApi = {
  // Dashboard Overview
  getAdminStats: async () => {
    try {
      const response = await api.get('/admin/dashboard/stats');
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // User Management
  getUsers: async (page = 1, limit = 10, role = '') => {
    try {
      const response = await api.get(`/admin/users?page=${page}&limit=${limit}&role=${role}`);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  updateUserStatus: async (userId, status) => {
    try {
      const response = await api.put(`/admin/users/${userId}/status`, { status });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  updateUserRole: async (userId, role) => {
    try {
      const response = await api.put(`/admin/users/${userId}/role`, { role });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // Order Management
  getAllOrders: async (status, page = 1, limit = 10) => {
    try {
      const response = await api.get(`/admin/orders?status=${status}&page=${page}&limit=${limit}`);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  processOrder: async (orderId, action) => {
    try {
      const response = await api.put(`/admin/orders/${orderId}/process`, { action });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  // Sales Reports
  generateSalesReport: async (params) => {
    try {
      const response = await api.get('/admin/reports/sales', { params });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  generateUserReport: async (params) => {
    try {
      const response = await api.get('/admin/reports/users', { params });
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },
};

// Authentication API Functions
export const authApi = {
  login: async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      const { token } = response.data;
      localStorage.setItem('token', token);
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },

  logout: () => {
    localStorage.removeItem('token');
    window.location.href = '/login';
  },

  getCurrentUser: async () => {
    try {
      const response = await api.get('/auth/me');
      return response.data;
    } catch (error) {
      handleApiError(error);
    }
  },
};

// Export the base api instance for custom requests
export default api; 