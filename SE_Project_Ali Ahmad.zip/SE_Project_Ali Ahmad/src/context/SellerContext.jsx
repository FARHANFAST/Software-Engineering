import React, { createContext, useContext, useState } from 'react';

const SellerContext = createContext();

export const useSeller = () => useContext(SellerContext);

export const SellerProvider = ({ children }) => {
  // Mock data for demonstration
  const [sellerData] = useState({
    totalEarnings: 124500.75,
    pendingOrders: 15,
    successfulOrders: 342,
    recentOrders: [
      { id: 1, customer: 'John Doe', amount: 99.99, status: 'Processing', date: '2024-03-15' },
      { id: 2, customer: 'Jane Smith', amount: 149.99, status: 'Shipped', date: '2024-03-14' },
      { id: 3, customer: 'Mike Johnson', amount: 79.99, status: 'Delivered', date: '2024-03-13' },
      { id: 4, customer: 'Sarah Wilson', amount: 199.99, status: 'Processing', date: '2024-03-12' },
    ],
    monthlySales: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      data: [12500, 15000, 18000, 16500, 21000, 19500],
    },
    products: [
      { id: 1, name: 'Wireless Earbuds', stock: 45, price: 99.99 },
      { id: 2, name: 'Smart Watch', stock: 30, price: 199.99 },
      { id: 3, name: 'Bluetooth Speaker', stock: 25, price: 79.99 },
    ],
  });

  const value = {
    sellerData,
  };

  return (
    <SellerContext.Provider value={value}>
      {children}
    </SellerContext.Provider>
  );
}; 