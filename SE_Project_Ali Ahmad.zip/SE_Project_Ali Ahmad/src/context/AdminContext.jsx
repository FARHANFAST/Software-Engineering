import React, { createContext, useContext, useState } from 'react';

const AdminContext = createContext();

export const useAdmin = () => useContext(AdminContext);

export const AdminProvider = ({ children }) => {
  // Mock data for demonstration
  const [adminData] = useState({
    users: [
      { id: 1, name: 'John Doe', email: 'john@example.com', role: 'customer', status: 'active' },
      { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'seller', status: 'active' },
      { id: 3, name: 'Mike Wilson', email: 'mike@example.com', role: 'customer', status: 'blocked' },
      { id: 4, name: 'Sarah Brown', email: 'sarah@example.com', role: 'seller', status: 'active' },
    ],
    orders: [
      { id: 1, customer: 'John Doe', total: 199.99, status: 'Pending', date: '2024-03-15', items: 3 },
      { id: 2, customer: 'Jane Smith', total: 349.99, status: 'Processing', date: '2024-03-14', items: 2 },
      { id: 3, customer: 'Mike Wilson', total: 79.99, status: 'Shipped', date: '2024-03-13', items: 1 },
      { id: 4, customer: 'Sarah Brown', total: 499.99, status: 'Delivered', date: '2024-03-12', items: 4 },
    ],
    salesData: {
      monthly: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        data: [45000, 52000, 49000, 60000, 55000, 65000],
      },
      yearly: {
        labels: ['2019', '2020', '2021', '2022', '2023', '2024'],
        data: [380000, 420000, 490000, 550000, 600000, 680000],
      },
    },
    stats: {
      totalUsers: 1245,
      activeUsers: 1180,
      blockedUsers: 65,
      totalOrders: 8567,
      pendingOrders: 123,
      totalRevenue: 1250000,
    },
  });

  const handleUserAction = (userId, action) => {
    // Mock function to handle user actions (block/unblock/role change)
    console.log(`User ${userId} action: ${action}`);
  };

  const handleOrderAction = (orderId, action) => {
    // Mock function to handle order actions (approve/process)
    console.log(`Order ${orderId} action: ${action}`);
  };

  const value = {
    adminData,
    handleUserAction,
    handleOrderAction,
  };

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>;
}; 