import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import './OrderDetails.css';

function OrderDetails() {
  const { orderId } = useParams();
  // This will be replaced with actual data from your MySQL database
  const [order] = useState({
    id: orderId,
    date: '2024-03-21',
    total: 99.99,
    status: 'Processing',
    items: [
      {
        id: 1,
        name: 'Product 1',
        price: 49.99,
        quantity: 2,
        image: 'https://via.placeholder.com/100'
      },
      {
        id: 2,
        name: 'Product 2',
        price: 29.99,
        quantity: 1,
        image: 'https://via.placeholder.com/100'
      }
    ],
    shippingAddress: {
      name: 'John Doe',
      street: '123 Main St',
      city: 'New York',
      state: 'NY',
      zipCode: '10001'
    },
    paymentMethod: 'Credit Card',
    shippingMethod: 'Standard Delivery',
    estimatedDelivery: '2024-03-25',
    trackingInfo: {
      orderPlaced: {
        date: '2024-03-21 10:30 AM',
        status: 'completed'
      },
      orderConfirmed: {
        date: '2024-03-21 11:15 AM',
        status: 'completed'
      },
      processing: {
        date: '2024-03-21 02:45 PM',
        status: 'completed'
      },
      shipped: {
        date: '2024-03-22 09:30 AM',
        status: 'completed',
        trackingNumber: '1Z999AA1234567890'
      },
      inTransit: {
        date: '2024-03-23 03:15 PM',
        status: 'current',
        location: 'New York Distribution Center'
      },
      outForDelivery: {
        date: null,
        status: 'pending'
      },
      delivered: {
        date: null,
        status: 'pending'
      }
    }
  });

  const handleCancelOrder = () => {
    // This will be implemented to connect with your MySQL backend
    alert('Order cancellation will be implemented with backend integration');
  };

  const getTrackingStatusClass = (status) => {
    switch (status) {
      case 'completed':
        return 'status-completed';
      case 'current':
        return 'status-current';
      case 'pending':
        return 'status-pending';
      default:
        return '';
    }
  };

  return (
    <div className="order-details">
      <div className="order-header">
        <h2>Order #{order.id}</h2>
        <div className="order-status">
          <span className={`status ${order.status.toLowerCase()}`}>
            {order.status}
          </span>
        </div>
      </div>

      <div className="order-info">
        <div className="info-section">
          <h3>Order Information</h3>
          <p>Order Date: {order.date}</p>
          <p>Estimated Delivery: {order.estimatedDelivery}</p>
          <p>Payment Method: {order.paymentMethod}</p>
          <p>Shipping Method: {order.shippingMethod}</p>
        </div>

        <div className="info-section">
          <h3>Shipping Address</h3>
          <p>{order.shippingAddress.name}</p>
          <p>{order.shippingAddress.street}</p>
          <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
        </div>
      </div>

      <div className="tracking-section">
        <h3>Order Tracking</h3>
        <div className="tracking-timeline">
          {Object.entries(order.trackingInfo).map(([key, info]) => (
            <div key={key} className={`tracking-step ${getTrackingStatusClass(info.status)}`}>
              <div className="step-icon">
                {info.status === 'completed' && '✓'}
                {info.status === 'current' && '●'}
                {info.status === 'pending' && '○'}
              </div>
              <div className="step-info">
                <h4>{key.replace(/([A-Z])/g, ' $1').trim()}</h4>
                {info.date && <p>{info.date}</p>}
                {info.location && <p>{info.location}</p>}
                {info.trackingNumber && <p>Tracking: {info.trackingNumber}</p>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="order-items">
        <h3>Order Items</h3>
        {order.items.map(item => (
          <div key={item.id} className="order-item">
            <img src={item.image} alt={item.name} />
            <div className="item-details">
              <h4>{item.name}</h4>
              <p>Quantity: {item.quantity}</p>
              <p>Price: ${item.price}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="order-summary">
        <h3>Order Summary</h3>
        <div className="summary-row">
          <span>Subtotal:</span>
          <span>${order.total}</span>
        </div>
        <div className="summary-row">
          <span>Shipping:</span>
          <span>Free</span>
        </div>
        <div className="summary-row total">
          <span>Total:</span>
          <span>${order.total}</span>
        </div>
      </div>

      <div className="order-actions">
        <Link to="/orders" className="back-button">Back to Orders</Link>
        {order.status === 'Processing' && (
          <button onClick={handleCancelOrder} className="cancel-button">
            Cancel Order
          </button>
        )}
      </div>
    </div>
  );
}

export default OrderDetails; 