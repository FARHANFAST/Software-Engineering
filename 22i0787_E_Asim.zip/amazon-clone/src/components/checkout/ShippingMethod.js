import React, { useState } from 'react';
import './ShippingMethod.css';

function ShippingMethod() {
  const [selectedMethod, setSelectedMethod] = useState('standard');

  const shippingMethods = [
    {
      id: 'standard',
      name: 'Standard Delivery',
      description: '5-7 business days',
      price: 0,
      estimatedDate: 'Estimated delivery: March 28-30'
    },
    {
      id: 'express',
      name: 'Express Delivery',
      description: '2-3 business days',
      price: 9.99,
      estimatedDate: 'Estimated delivery: March 25-26'
    }
  ];

  return (
    <div className="shipping-method">
      <h3>Shipping Method</h3>
      <div className="shipping-options">
        {shippingMethods.map(method => (
          <div 
            key={method.id}
            className={`shipping-option ${selectedMethod === method.id ? 'selected' : ''}`}
            onClick={() => setSelectedMethod(method.id)}
          >
            <input
              type="radio"
              id={method.id}
              name="shippingMethod"
              value={method.id}
              checked={selectedMethod === method.id}
              onChange={() => setSelectedMethod(method.id)}
            />
            <label htmlFor={method.id}>
              <div className="option-details">
                <h4>{method.name}</h4>
                <p>{method.description}</p>
                <p className="estimated-date">{method.estimatedDate}</p>
                {method.price > 0 && (
                  <p className="price">+${method.price.toFixed(2)}</p>
                )}
              </div>
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ShippingMethod; 