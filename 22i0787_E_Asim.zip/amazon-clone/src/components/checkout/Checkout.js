import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import DeliveryAddress from './DeliveryAddress';
import ShippingMethod from './ShippingMethod';
import PaymentOptions from './PaymentOptions';
import './Checkout.css';

function Checkout() {
  const cart = useSelector(state => state.cart);
  const [discountCode, setDiscountCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);

  const handleApplyDiscount = () => {
    // This would typically validate against a backend
    if (discountCode === 'SAVE10') {
      setDiscountAmount(cart.total * 0.1); // 10% discount
      setDiscountApplied(true);
    } else {
      alert('Invalid discount code');
    }
  };

  const finalTotal = cart.total - discountAmount;

  return (
    <div className="checkout">
      <h2>Checkout</h2>
      
      <div className="checkout-grid">
        <div className="checkout-main">
          <DeliveryAddress />
          <ShippingMethod />
          <PaymentOptions />
        </div>

        <div className="checkout-summary">
          <h3>Order Summary</h3>
          <div className="summary-item">
            <span>Subtotal:</span>
            <span>${cart.total.toFixed(2)}</span>
          </div>
          
          <div className="discount-section">
            <input
              type="text"
              placeholder="Enter discount code"
              value={discountCode}
              onChange={(e) => setDiscountCode(e.target.value)}
              disabled={discountApplied}
            />
            <button 
              onClick={handleApplyDiscount}
              disabled={discountApplied}
              className="apply-discount-btn"
            >
              Apply
            </button>
          </div>

          {discountApplied && (
            <div className="summary-item discount">
              <span>Discount:</span>
              <span>-${discountAmount.toFixed(2)}</span>
            </div>
          )}

          <div className="summary-item total">
            <span>Total:</span>
            <span>${finalTotal.toFixed(2)}</span>
          </div>

          <button className="place-order-btn">
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
}

export default Checkout; 