import React from 'react';
import { useDispatch } from 'react-redux';
import { addToCart } from '../store/cartSlice';
import './Home.css';

const products = [
  {
    id: 1,
    title: 'Wireless Headphones',
    price: 99.99,
    image: 'https://via.placeholder.com/200',
    rating: 4.5,
    description: 'High-quality wireless headphones with noise cancellation'
  },
  {
    id: 2,
    title: 'Smart Watch',
    price: 199.99,
    image: 'https://via.placeholder.com/200',
    rating: 4.8,
    description: 'Fitness tracking smartwatch with heart rate monitoring'
  },
  {
    id: 3,
    title: 'Laptop Backpack',
    price: 49.99,
    image: 'https://via.placeholder.com/200',
    rating: 4.2,
    description: 'Durable laptop backpack with multiple compartments'
  },
  {
    id: 4,
    title: 'Coffee Maker',
    price: 79.99,
    image: 'https://via.placeholder.com/200',
    rating: 4.6,
    description: 'Programmable coffee maker with 12-cup capacity'
  }
];

function Home() {
  const dispatch = useDispatch();

  const handleAddToCart = (product) => {
    dispatch(addToCart(product));
  };

  return (
    <div className="home">
      <div className="banner">
        <img src="https://via.placeholder.com/1200x300" alt="Banner" />
      </div>
      <div className="products-grid">
        {products.map(product => (
          <div key={product.id} className="product-card">
            <img src={product.image} alt={product.title} />
            <h3>{product.title}</h3>
            <div className="rating">
              {'★'.repeat(Math.floor(product.rating))}
              {'☆'.repeat(5 - Math.floor(product.rating))}
            </div>
            <p className="price">${product.price}</p>
            <p className="description">{product.description}</p>
            <button 
              className="add-to-cart"
              onClick={() => handleAddToCart(product)}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home; 