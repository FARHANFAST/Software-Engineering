import React, { useState } from 'react';
import {
  Box,
  Typography,
  Rating,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Avatar,
  Grid,
  Paper,
  Divider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from '@mui/material';
import {
  Star as StarIcon,
  Sort as SortIcon,
  ThumbUp as ThumbUpIcon,
} from '@mui/icons-material';

// Dummy reviews data - in a real app, this would come from your backend
const initialReviews = [
  {
    id: 1,
    userId: 'user1',
    userName: 'John Doe',
    rating: 5,
    date: '2024-03-10',
    title: 'Excellent Product!',
    comment: 'This product exceeded my expectations. The quality is outstanding and it works perfectly.',
    helpful: 12,
    verified: true,
  },
  {
    id: 2,
    userId: 'user2',
    userName: 'Jane Smith',
    rating: 4,
    date: '2024-03-08',
    title: 'Good but could be better',
    comment: 'Overall good product but there is room for improvement in terms of battery life.',
    helpful: 8,
    verified: true,
  },
];

function Reviews({ productId }) {
  const [reviews, setReviews] = useState(initialReviews);
  const [openReviewDialog, setOpenReviewDialog] = useState(false);
  const [sortBy, setSortBy] = useState('recent');
  const [newReview, setNewReview] = useState({
    rating: 0,
    title: '',
    comment: '',
  });
  const [hoveredRating, setHoveredRating] = useState(-1);

  const averageRating = reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length;
  const ratingCounts = reviews.reduce((acc, review) => {
    acc[review.rating] = (acc[review.rating] || 0) + 1;
    return acc;
  }, {});

  const handleSortChange = (event) => {
    setSortBy(event.target.value);
    let sortedReviews = [...reviews];
    switch (event.target.value) {
      case 'recent':
        sortedReviews.sort((a, b) => new Date(b.date) - new Date(a.date));
        break;
      case 'helpful':
        sortedReviews.sort((a, b) => b.helpful - a.helpful);
        break;
      case 'rating-high':
        sortedReviews.sort((a, b) => b.rating - a.rating);
        break;
      case 'rating-low':
        sortedReviews.sort((a, b) => a.rating - b.rating);
        break;
      default:
        break;
    }
    setReviews(sortedReviews);
  };

  const handleReviewSubmit = () => {
    const newReviewObj = {
      id: reviews.length + 1,
      userId: 'currentUser',
      userName: 'Current User',
      rating: newReview.rating,
      date: new Date().toISOString().split('T')[0],
      title: newReview.title,
      comment: newReview.comment,
      helpful: 0,
      verified: true,
    };
    setReviews([newReviewObj, ...reviews]);
    setOpenReviewDialog(false);
    setNewReview({ rating: 0, title: '', comment: '' });
  };

  const handleHelpful = (reviewId) => {
    setReviews(
      reviews.map((review) =>
        review.id === reviewId
          ? { ...review, helpful: review.helpful + 1 }
          : review
      )
    );
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h5">Customer Reviews</Typography>
        <Button variant="contained" onClick={() => setOpenReviewDialog(true)}>
          Write a Review
        </Button>
      </Box>

      {/* Rating Summary */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h3">{averageRating.toFixed(1)}</Typography>
              <Rating value={averageRating} precision={0.1} readOnly />
              <Typography variant="body2" color="text.secondary">
                {reviews.length} ratings
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={8}>
            {[5, 4, 3, 2, 1].map((rating) => (
              <Box
                key={rating}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  mb: 1,
                }}
              >
                <Typography sx={{ mr: 1 }}>{rating} star</Typography>
                <Box
                  sx={{
                    flexGrow: 1,
                    bgcolor: 'grey.200',
                    height: 8,
                    borderRadius: 1,
                    mr: 1,
                  }}
                >
                  <Box
                    sx={{
                      width: `${((ratingCounts[rating] || 0) / reviews.length) * 100}%`,
                      height: '100%',
                      bgcolor: 'primary.main',
                      borderRadius: 1,
                    }}
                  />
                </Box>
                <Typography>
                  {((ratingCounts[rating] || 0) / reviews.length * 100).toFixed(0)}%
                </Typography>
              </Box>
            ))}
          </Grid>
        </Grid>
      </Paper>

      {/* Sort Reviews */}
      <Box sx={{ mb: 3 }}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Sort by</InputLabel>
          <Select
            value={sortBy}
            onChange={handleSortChange}
            startAdornment={<SortIcon sx={{ mr: 1 }} />}
          >
            <MenuItem value="recent">Most Recent</MenuItem>
            <MenuItem value="helpful">Most Helpful</MenuItem>
            <MenuItem value="rating-high">Highest Rating</MenuItem>
            <MenuItem value="rating-low">Lowest Rating</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Reviews List */}
      <Box>
        {reviews.map((review) => (
          <Paper key={review.id} sx={{ p: 3, mb: 2 }}>
            <Grid container spacing={2}>
              <Grid item>
                <Avatar>{review.userName[0]}</Avatar>
              </Grid>
              <Grid item xs>
                <Typography variant="subtitle1">{review.userName}</Typography>
                <Rating value={review.rating} readOnly size="small" />
                {review.verified && (
                  <Typography
                    variant="caption"
                    color="success.main"
                    sx={{ ml: 1 }}
                  >
                    Verified Purchase
                  </Typography>
                )}
                <Typography variant="h6" gutterBottom>
                  {review.title}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Reviewed on {review.date}
                </Typography>
                <Typography paragraph>{review.comment}</Typography>
                <Button
                  startIcon={<ThumbUpIcon />}
                  onClick={() => handleHelpful(review.id)}
                  size="small"
                >
                  Helpful ({review.helpful})
                </Button>
              </Grid>
            </Grid>
          </Paper>
        ))}
      </Box>

      {/* Write Review Dialog */}
      <Dialog
        open={openReviewDialog}
        onClose={() => setOpenReviewDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Write a Review</DialogTitle>
        <DialogContent>
          <Box sx={{ py: 2 }}>
            <Box sx={{ mb: 3, textAlign: 'center' }}>
              <Rating
                value={newReview.rating}
                onChange={(event, newValue) => {
                  setNewReview({ ...newReview, rating: newValue });
                }}
                onChangeActive={(event, newHover) => {
                  setHoveredRating(newHover);
                }}
                size="large"
              />
              <Typography variant="body2" sx={{ mt: 1 }}>
                {hoveredRating !== -1
                  ? ['Terrible', 'Poor', 'Average', 'Good', 'Excellent'][
                      hoveredRating - 1
                    ]
                  : newReview.rating
                  ? ['Terrible', 'Poor', 'Average', 'Good', 'Excellent'][
                      newReview.rating - 1
                    ]
                  : 'Rate this product'}
              </Typography>
            </Box>
            <TextField
              fullWidth
              label="Review Title"
              value={newReview.title}
              onChange={(e) =>
                setNewReview({ ...newReview, title: e.target.value })
              }
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Review Comment"
              value={newReview.comment}
              onChange={(e) =>
                setNewReview({ ...newReview, comment: e.target.value })
              }
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenReviewDialog(false)}>Cancel</Button>
          <Button
            onClick={handleReviewSubmit}
            variant="contained"
            disabled={!newReview.rating || !newReview.comment}
          >
            Submit Review
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

export default Reviews; 