import React from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Divider,
  Grid,
  Button,
} from '@mui/material';
import {
  Print as PrintIcon,
  Email as EmailIcon,
  Download as DownloadIcon,
} from '@mui/icons-material';

function Invoice({ order }) {
  const handlePrint = () => {
    window.print();
  };

  const handleEmail = () => {
    // In a real app, this would trigger an API call to send the invoice via email
    alert('Email functionality will be implemented with backend integration');
  };

  const handleDownload = () => {
    // In a real app, this would generate a PDF and trigger download
    alert('PDF download functionality will be implemented with backend integration');
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 4 }} className="invoice-container">
        {/* Invoice Header */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 4 }}>
          <Box>
            <Typography variant="h4" gutterBottom>
              INVOICE
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Order #{order.id}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Date: {new Date(order.date).toLocaleDateString()}
            </Typography>
          </Box>
          <Box>
            <img
              src="/logo.png"
              alt="Amazon Clone Logo"
              style={{ height: 50 }}
            />
            <Typography variant="body2">Amazon Clone Store</Typography>
            <Typography variant="body2">123 E-commerce Street</Typography>
            <Typography variant="body2">contact@amazonclone.com</Typography>
          </Box>
        </Box>

        {/* Customer Information */}
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={6}>
            <Typography variant="h6" gutterBottom>
              Bill To:
            </Typography>
            <Typography>{order.customer?.name || 'Customer Name'}</Typography>
            <Typography>{order.customer?.address || 'Customer Address'}</Typography>
            <Typography>{order.customer?.email || 'customer@email.com'}</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="h6" gutterBottom>
              Ship To:
            </Typography>
            <Typography>{order.shippingAddress?.name || order.customer?.name}</Typography>
            <Typography>{order.shippingAddress?.address || 'Shipping Address'}</Typography>
            <Typography>{order.shippingAddress?.phone || 'Phone Number'}</Typography>
          </Grid>
        </Grid>

        <Divider sx={{ mb: 4 }} />

        {/* Order Items */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Order Items
          </Typography>
          <Grid container sx={{ fontWeight: 'bold', mb: 2 }}>
            <Grid item xs={6}>
              <Typography>Description</Typography>
            </Grid>
            <Grid item xs={2}>
              <Typography>Quantity</Typography>
            </Grid>
            <Grid item xs={2}>
              <Typography>Price</Typography>
            </Grid>
            <Grid item xs={2}>
              <Typography>Total</Typography>
            </Grid>
          </Grid>
          {order.items.map((item, index) => (
            <Grid container key={index} sx={{ mb: 1 }}>
              <Grid item xs={6}>
                <Typography>{item.name}</Typography>
              </Grid>
              <Grid item xs={2}>
                <Typography>{item.quantity}</Typography>
              </Grid>
              <Grid item xs={2}>
                <Typography>${item.price.toFixed(2)}</Typography>
              </Grid>
              <Grid item xs={2}>
                <Typography>${(item.quantity * item.price).toFixed(2)}</Typography>
              </Grid>
            </Grid>
          ))}
        </Box>

        {/* Order Summary */}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 4 }}>
          <Box sx={{ width: '300px' }}>
            <Grid container spacing={1}>
              <Grid item xs={8}>
                <Typography>Subtotal:</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography>${order.total.toFixed(2)}</Typography>
              </Grid>
              <Grid item xs={8}>
                <Typography>Shipping ({order.shippingMethod}):</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography>${(order.shippingCost || 0).toFixed(2)}</Typography>
              </Grid>
              {order.discount > 0 && (
                <>
                  <Grid item xs={8}>
                    <Typography>Discount:</Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography>-${order.discount.toFixed(2)}</Typography>
                  </Grid>
                </>
              )}
              <Grid item xs={8}>
                <Typography variant="h6">Total:</Typography>
              </Grid>
              <Grid item xs={4}>
                <Typography variant="h6">
                  ${(order.total + (order.shippingCost || 0) - (order.discount || 0)).toFixed(2)}
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </Box>

        {/* Invoice Footer */}
        <Box sx={{ mt: 4 }}>
          <Typography variant="body2" color="text.secondary" gutterBottom>
            Payment Method: {order.paymentMethod || 'Credit Card'}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Thank you for shopping with Amazon Clone!
          </Typography>
        </Box>

        {/* Action Buttons */}
        <Box sx={{ mt: 4, display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
          <Button
            variant="outlined"
            startIcon={<PrintIcon />}
            onClick={handlePrint}
          >
            Print
          </Button>
          <Button
            variant="outlined"
            startIcon={<EmailIcon />}
            onClick={handleEmail}
          >
            Email
          </Button>
          <Button
            variant="contained"
            startIcon={<DownloadIcon />}
            onClick={handleDownload}
          >
            Download PDF
          </Button>
        </Box>
      </Paper>
    </Container>
  );
}

export default Invoice; 