import React from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  Grid,
  Divider,
  Chip,
} from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  Print as PrintIcon,
  Email as EmailIcon,
} from '@mui/icons-material';
import { Link } from 'react-router-dom';

// Dummy order data - in a real app, this would come from your backend
const orderData = {
  orderId: 'ORD123456789',
  date: new Date().toLocaleDateString(),
  status: 'Confirmed',
  estimatedDelivery: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString(),
  items: [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 99.99,
      quantity: 2,
    },
    {
      id: 2,
      name: 'Smart Watch',
      price: 199.99,
      quantity: 1,
    },
  ],
  shippingAddress: {
    name: 'John Doe',
    address: '123 Main St',
    city: 'New York',
    state: 'NY',
    postalCode: '10001',
    phone: '(123) 456-7890',
  },
  paymentMethod: 'Credit Card',
  shippingMethod: 'Standard Shipping',
  subtotal: 399.97,
  shipping: 5.99,
  discount: 20,
  total: 385.96,
};

function OrderConfirmation() {
  const handlePrintInvoice = () => {
    window.print();
  };

  const handleEmailInvoice = () => {
    // Handle email invoice functionality
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 4 }}>
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <CheckCircleIcon color="success" sx={{ fontSize: 60, mb: 2 }} />
          <Typography variant="h4" gutterBottom>
            Order Confirmed!
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Thank you for your purchase
          </Typography>
        </Box>

        <Box sx={{ mb: 4 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="text.secondary">
                Order Number
              </Typography>
              <Typography variant="body1">{orderData.orderId}</Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="text.secondary">
                Order Date
              </Typography>
              <Typography variant="body1">{orderData.date}</Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="text.secondary">
                Status
              </Typography>
              <Chip
                label={orderData.status}
                color="success"
                size="small"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="text.secondary">
                Estimated Delivery
              </Typography>
              <Typography variant="body1">{orderData.estimatedDelivery}</Typography>
            </Grid>
          </Grid>
        </Box>

        <Divider sx={{ my: 3 }} />

        <Typography variant="h6" gutterBottom>
          Order Details
        </Typography>
        <Box sx={{ mb: 4 }}>
          {orderData.items.map((item) => (
            <Grid container key={item.id} spacing={2} sx={{ mb: 2 }}>
              <Grid item xs={6}>
                <Typography>{item.name}</Typography>
                <Typography variant="body2" color="text.secondary">
                  Quantity: {item.quantity}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography align="right">
                  ${(item.price * item.quantity).toFixed(2)}
                </Typography>
              </Grid>
            </Grid>
          ))}
          <Divider sx={{ my: 2 }} />
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography>Subtotal</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography align="right">${orderData.subtotal.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography>Shipping</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography align="right">${orderData.shipping.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography>Discount</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography align="right">-${orderData.discount.toFixed(2)}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="h6">Total</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="h6" align="right">
                ${orderData.total.toFixed(2)}
              </Typography>
            </Grid>
          </Grid>
        </Box>

        <Divider sx={{ my: 3 }} />

        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Shipping Address
            </Typography>
            <Typography>
              {orderData.shippingAddress.name}
              <br />
              {orderData.shippingAddress.address}
              <br />
              {orderData.shippingAddress.city}, {orderData.shippingAddress.state}{' '}
              {orderData.shippingAddress.postalCode}
              <br />
              Phone: {orderData.shippingAddress.phone}
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>
              Payment & Shipping Method
            </Typography>
            <Typography>
              Payment: {orderData.paymentMethod}
              <br />
              Shipping: {orderData.shippingMethod}
            </Typography>
          </Grid>
        </Grid>

        <Box sx={{ mt: 4, display: 'flex', gap: 2, justifyContent: 'center' }}>
          <Button
            variant="outlined"
            startIcon={<PrintIcon />}
            onClick={handlePrintInvoice}
          >
            Print Invoice
          </Button>
          <Button
            variant="outlined"
            startIcon={<EmailIcon />}
            onClick={handleEmailInvoice}
          >
            Email Invoice
          </Button>
          <Button
            variant="contained"
            component={Link}
            to="/orders"
          >
            View All Orders
          </Button>
        </Box>
      </Paper>
    </Container>
  );
}

export default OrderConfirmation; 