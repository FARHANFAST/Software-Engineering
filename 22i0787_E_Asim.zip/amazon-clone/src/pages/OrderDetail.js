import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  Stepper,
  Step,
  StepLabel,
  Tabs,
  Tab,
} from '@mui/material';
import Invoice from '../components/Invoice';

function OrderDetail() {
  const { orderId } = useParams();
  const [activeTab, setActiveTab] = useState(0);
  const [order, setOrder] = useState(null);

  // In a real app, this would fetch order data from an API
  useEffect(() => {
    // Simulated order data
    const mockOrder = {
      id: orderId,
      date: '2024-03-15',
      status: 'Processing',
      total: 385.96,
      items: [
        {
          name: 'Wireless Headphones',
          quantity: 2,
          price: 99.99,
        },
        {
          name: 'Smart Watch',
          quantity: 1,
          price: 199.99,
        },
      ],
      shippingMethod: 'Standard Shipping',
      shippingCost: 12.99,
      estimatedDelivery: '2024-03-20',
      customer: {
        name: 'John Doe',
        email: 'john@example.com',
        address: '123 Main St, City, Country',
      },
      shippingAddress: {
        name: 'John Doe',
        address: '123 Main St, City, Country',
        phone: '+1 234 567 8900',
      },
      paymentMethod: 'Credit Card',
      discount: 15.00,
    };
    setOrder(mockOrder);
  }, [orderId]);

  const orderSteps = [
    'Order Placed',
    'Processing',
    'Shipped',
    'Out for Delivery',
    'Delivered',
  ];

  const getCurrentStep = () => {
    switch (order?.status) {
      case 'Processing':
        return 1;
      case 'Shipped':
        return 2;
      case 'Out for Delivery':
        return 3;
      case 'Delivered':
        return 4;
      default:
        return 0;
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  if (!order) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography>Loading order details...</Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Order Details
      </Typography>

      <Box sx={{ mb: 4 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="Order Status" />
          <Tab label="Invoice" />
        </Tabs>
      </Box>

      {activeTab === 0 ? (
        <>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Order #{order.id}
            </Typography>
            <Typography color="text.secondary" gutterBottom>
              Placed on {new Date(order.date).toLocaleDateString()}
            </Typography>

            <Box sx={{ mt: 4, mb: 4 }}>
              <Stepper activeStep={getCurrentStep()} alternativeLabel>
                {orderSteps.map((label) => (
                  <Step key={label}>
                    <StepLabel>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
            </Box>

            <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
              Shipping Details
            </Typography>
            <Typography>
              {order.shippingAddress.name}
            </Typography>
            <Typography>
              {order.shippingAddress.address}
            </Typography>
            <Typography>
              {order.shippingAddress.phone}
            </Typography>

            <Typography variant="h6" gutterBottom sx={{ mt: 4 }}>
              Items
            </Typography>
            {order.items.map((item, index) => (
              <Box key={index} sx={{ mb: 2 }}>
                <Typography>
                  {item.quantity}x {item.name} - ${item.price.toFixed(2)}
                </Typography>
              </Box>
            ))}

            <Box sx={{ mt: 4 }}>
              <Typography variant="subtitle1">
                Subtotal: ${order.total.toFixed(2)}
              </Typography>
              <Typography variant="subtitle1">
                Shipping: ${order.shippingCost.toFixed(2)}
              </Typography>
              {order.discount > 0 && (
                <Typography variant="subtitle1">
                  Discount: -${order.discount.toFixed(2)}
                </Typography>
              )}
              <Typography variant="h6" sx={{ mt: 1 }}>
                Total: ${(order.total + order.shippingCost - order.discount).toFixed(2)}
              </Typography>
            </Box>

            {order.status === 'Processing' && (
              <Box sx={{ mt: 4 }}>
                <Button variant="contained" color="error">
                  Cancel Order
                </Button>
              </Box>
            )}
          </Paper>
        </>
      ) : (
        <Invoice order={order} />
      )}
    </Container>
  );
}

export default OrderDetail; 