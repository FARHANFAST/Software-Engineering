import React from 'react';
import { Link } from 'react-router-dom';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
  Paper,
} from '@mui/material';

// Dummy data for featured products
const featuredProducts = [
  {
    id: 1,
    name: 'Wireless Headphones',
    price: 99.99,
    image: 'https://via.placeholder.com/200',
    category: 'Electronics',
  },
  {
    id: 2,
    name: 'Smart Watch',
    price: 199.99,
    image: 'https://via.placeholder.com/200',
    category: 'Electronics',
  },
  {
    id: 3,
    name: 'Running Shoes',
    price: 79.99,
    image: 'https://via.placeholder.com/200',
    category: 'Fashion',
  },
  {
    id: 4,
    name: 'Coffee Maker',
    price: 49.99,
    image: 'https://via.placeholder.com/200',
    category: 'Home & Kitchen',
  },
];

// Dummy data for categories
const categories = [
  {
    id: 1,
    name: 'Electronics',
    image: 'https://via.placeholder.com/150',
  },
  {
    id: 2,
    name: 'Fashion',
    image: 'https://via.placeholder.com/150',
  },
  {
    id: 3,
    name: 'Home & Kitchen',
    image: 'https://via.placeholder.com/150',
  },
  {
    id: 4,
    name: 'Books',
    image: 'https://via.placeholder.com/150',
  },
];

function Home() {
  return (
    <Container maxWidth="lg">
      {/* Hero Section */}
      <Paper
        sx={{
          position: 'relative',
          backgroundColor: 'grey.800',
          color: '#fff',
          mb: 4,
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
          backgroundImage: 'url(https://via.placeholder.com/1200x400)',
          height: '400px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            bottom: 0,
            right: 0,
            left: 0,
            backgroundColor: 'rgba(0,0,0,.3)',
          }}
        />
        <Box
          sx={{
            position: 'relative',
            p: { xs: 3, md: 6 },
            pr: { md: 0 },
            textAlign: 'center',
          }}
        >
          <Typography component="h1" variant="h3" color="inherit" gutterBottom>
            Welcome to Amazon Clone
          </Typography>
          <Typography variant="h5" color="inherit" paragraph>
            Discover amazing products at great prices
          </Typography>
          <Button variant="contained" color="primary" size="large" component={Link} to="/products">
            Shop Now
          </Button>
        </Box>
      </Paper>

      {/* Categories Section */}
      <Typography variant="h4" gutterBottom sx={{ mt: 4 }}>
        Shop by Category
      </Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {categories.map((category) => (
          <Grid item xs={6} sm={3} key={category.id}>
            <Card
              component={Link}
              to={`/products?category=${category.name}`}
              sx={{ textDecoration: 'none' }}
            >
              <CardMedia
                component="img"
                height="150"
                image={category.image}
                alt={category.name}
              />
              <CardContent>
                <Typography gutterBottom variant="h6" component="div" align="center">
                  {category.name}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Featured Products Section */}
      <Typography variant="h4" gutterBottom sx={{ mt: 4 }}>
        Featured Products
      </Typography>
      <Grid container spacing={3}>
        {featuredProducts.map((product) => (
          <Grid item xs={12} sm={6} md={3} key={product.id}>
            <Card>
              <CardMedia
                component="img"
                height="200"
                image={product.image}
                alt={product.name}
              />
              <CardContent>
                <Typography gutterBottom variant="h6" component="div">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {product.category}
                </Typography>
                <Typography variant="h6" color="primary" sx={{ mt: 1 }}>
                  ${product.price}
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  sx={{ mt: 2 }}
                  component={Link}
                  to={`/product/${product.id}`}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default Home; 