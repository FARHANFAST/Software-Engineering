import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  Grid,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  InputAdornment,
  IconButton,
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterIcon,
  Cancel as CancelIcon,
} from '@mui/icons-material';
import { Link } from 'react-router-dom';

// Dummy orders data - in a real app, this would come from your backend
const initialOrders = [
  {
    id: 'ORD123456789',
    date: '2024-03-15',
    total: 385.96,
    status: 'Processing',
    items: [
      {
        name: 'Wireless Headphones',
        quantity: 2,
        price: 99.99,
      },
      {
        name: 'Smart Watch',
        quantity: 1,
        price: 199.99,
      },
    ],
    shippingMethod: 'Standard Shipping',
    estimatedDelivery: '2024-03-20',
  },
  {
    id: 'ORD987654321',
    date: '2024-03-14',
    total: 149.99,
    status: 'Shipped',
    items: [
      {
        name: 'Running Shoes',
        quantity: 1,
        price: 149.99,
      },
    ],
    shippingMethod: 'Express Shipping',
    estimatedDelivery: '2024-03-16',
  },
  {
    id: 'ORD456789123',
    date: '2024-03-13',
    total: 49.99,
    status: 'Delivered',
    items: [
      {
        name: 'Coffee Maker',
        quantity: 1,
        price: 49.99,
      },
    ],
    shippingMethod: 'Standard Shipping',
    estimatedDelivery: '2024-03-18',
  },
];

function Orders() {
  const [orders, setOrders] = useState(initialOrders);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleFilterChange = (event) => {
    setFilterStatus(event.target.value);
  };

  const handleCancelOrder = (order) => {
    setSelectedOrder(order);
    setCancelDialogOpen(true);
  };

  const handleConfirmCancel = () => {
    setOrders(
      orders.map((order) =>
        order.id === selectedOrder.id
          ? { ...order, status: 'Cancelled' }
          : order
      )
    );
    setCancelDialogOpen(false);
    setSelectedOrder(null);
    setCancelReason('');
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'processing':
        return 'warning';
      case 'shipped':
        return 'info';
      case 'delivered':
        return 'success';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterStatus === 'all' || order.status.toLowerCase() === filterStatus.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        My Orders
      </Typography>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            placeholder="Search orders..."
            value={searchTerm}
            onChange={handleSearch}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            select
            value={filterStatus}
            onChange={handleFilterChange}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <FilterIcon />
                </InputAdornment>
              ),
            }}
          >
            <MenuItem value="all">All Orders</MenuItem>
            <MenuItem value="processing">Processing</MenuItem>
            <MenuItem value="shipped">Shipped</MenuItem>
            <MenuItem value="delivered">Delivered</MenuItem>
            <MenuItem value="cancelled">Cancelled</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      {filteredOrders.map((order) => (
        <Paper key={order.id} sx={{ mb: 3, p: 3 }}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="subtitle2" color="text.secondary">
                    Order #{order.id}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Placed on {new Date(order.date).toLocaleDateString()}
                  </Typography>
                </Box>
                <Chip
                  label={order.status}
                  color={getStatusColor(order.status)}
                  size="small"
                />
              </Box>
            </Grid>

            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Items
              </Typography>
              {order.items.map((item, index) => (
                <Box key={index} sx={{ mb: 1 }}>
                  <Typography>
                    {item.quantity}x {item.name} - ${item.price.toFixed(2)}
                  </Typography>
                </Box>
              ))}
            </Grid>

            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle2" color="text.secondary">
                Shipping Method
              </Typography>
              <Typography>{order.shippingMethod}</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Estimated Delivery: {new Date(order.estimatedDelivery).toLocaleDateString()}
              </Typography>
            </Grid>

            <Grid item xs={12} sm={6}>
              <Box sx={{ textAlign: 'right' }}>
                <Typography variant="h6">
                  Total: ${order.total.toFixed(2)}
                </Typography>
                <Box sx={{ mt: 2 }}>
                  <Button
                    variant="outlined"
                    component={Link}
                    to={`/order/${order.id}`}
                    sx={{ mr: 1 }}
                  >
                    View Details
                  </Button>
                  {order.status === 'Processing' && (
                    <Button
                      variant="outlined"
                      color="error"
                      startIcon={<CancelIcon />}
                      onClick={() => handleCancelOrder(order)}
                    >
                      Cancel Order
                    </Button>
                  )}
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      ))}

      <Dialog open={cancelDialogOpen} onClose={() => setCancelDialogOpen(false)}>
        <DialogTitle>Cancel Order</DialogTitle>
        <DialogContent>
          <Typography gutterBottom>
            Are you sure you want to cancel this order?
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Reason for Cancellation"
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelDialogOpen(false)}>No, Keep Order</Button>
          <Button onClick={handleConfirmCancel} color="error" variant="contained">
            Yes, Cancel Order
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default Orders; 