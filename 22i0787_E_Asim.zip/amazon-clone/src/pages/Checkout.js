import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Box,
  Button,
  Grid,
  TextField,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Divider,
  Alert,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

// Step components
const AddressForm = ({ formData, setFormData }) => (
  <Grid container spacing={2}>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="First Name"
        value={formData.firstName}
        onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="Last Name"
        value={formData.lastName}
        onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
      />
    </Grid>
    <Grid item xs={12}>
      <TextField
        required
        fullWidth
        label="Address Line 1"
        value={formData.address1}
        onChange={(e) => setFormData({ ...formData, address1: e.target.value })}
      />
    </Grid>
    <Grid item xs={12}>
      <TextField
        fullWidth
        label="Address Line 2"
        value={formData.address2}
        onChange={(e) => setFormData({ ...formData, address2: e.target.value })}
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="City"
        value={formData.city}
        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="State"
        value={formData.state}
        onChange={(e) => setFormData({ ...formData, state: e.target.value })}
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="Postal Code"
        value={formData.postalCode}
        onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
      />
    </Grid>
    <Grid item xs={12} sm={6}>
      <TextField
        required
        fullWidth
        label="Phone Number"
        value={formData.phone}
        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
      />
    </Grid>
  </Grid>
);

const ShippingForm = ({ formData, setFormData }) => (
  <FormControl component="fieldset">
    <FormLabel component="legend">Shipping Method</FormLabel>
    <RadioGroup
      value={formData.shippingMethod}
      onChange={(e) =>
        setFormData({
          ...formData,
          shippingMethod: e.target.value,
          shippingCost: e.target.value === 'standard' ? 5.99 : 14.99,
        })
      }
    >
      <FormControlLabel
        value="standard"
        control={<Radio />}
        label={
          <Box>
            <Typography variant="body1">Standard Shipping (3-5 business days)</Typography>
            <Typography variant="body2" color="text.secondary">
              $5.99
            </Typography>
          </Box>
        }
      />
      <FormControlLabel
        value="express"
        control={<Radio />}
        label={
          <Box>
            <Typography variant="body1">Express Shipping (1-2 business days)</Typography>
            <Typography variant="body2" color="text.secondary">
              $14.99
            </Typography>
          </Box>
        }
      />
    </RadioGroup>
  </FormControl>
);

const PaymentForm = ({ formData, setFormData }) => (
  <Box>
    <FormControl component="fieldset" sx={{ mb: 3 }}>
      <FormLabel component="legend">Payment Method</FormLabel>
      <RadioGroup
        value={formData.paymentMethod}
        onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
      >
        <FormControlLabel
          value="card"
          control={<Radio />}
          label="Credit/Debit Card"
        />
        <FormControlLabel
          value="cod"
          control={<Radio />}
          label="Cash on Delivery"
        />
        <FormControlLabel
          value="wallet"
          control={<Radio />}
          label="Digital Wallet"
        />
      </RadioGroup>
    </FormControl>

    {formData.paymentMethod === 'card' && (
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            required
            fullWidth
            label="Card Number"
            value={formData.cardNumber}
            onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            fullWidth
            label="Expiry Date"
            placeholder="MM/YY"
            value={formData.cardExpiry}
            onChange={(e) => setFormData({ ...formData, cardExpiry: e.target.value })}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            required
            fullWidth
            label="CVV"
            value={formData.cardCvv}
            onChange={(e) => setFormData({ ...formData, cardCvv: e.target.value })}
          />
        </Grid>
      </Grid>
    )}

    <Box sx={{ mt: 3 }}>
      <TextField
        fullWidth
        label="Discount Code"
        value={formData.discountCode}
        onChange={(e) => setFormData({ ...formData, discountCode: e.target.value })}
      />
      <Button
        variant="outlined"
        sx={{ mt: 1 }}
        onClick={() => {/* Handle discount code validation */}}
      >
        Apply Code
      </Button>
    </Box>
  </Box>
);

const OrderSummary = ({ formData }) => {
  const subtotal = 299.97; // This would come from your cart
  const shipping = formData.shippingCost || 5.99;
  const discount = formData.discountCode ? 20 : 0; // Example discount
  const total = subtotal + shipping - discount;

  return (
    <Box>
      <Typography variant="h6" gutterBottom>
        Order Summary
      </Typography>
      <Box sx={{ my: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography>Subtotal</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography align="right">${subtotal.toFixed(2)}</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography>Shipping</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography align="right">${shipping.toFixed(2)}</Typography>
          </Grid>
          {discount > 0 && (
            <>
              <Grid item xs={6}>
                <Typography>Discount</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography align="right">-${discount.toFixed(2)}</Typography>
              </Grid>
            </>
          )}
          <Grid item xs={12}>
            <Divider sx={{ my: 1 }} />
          </Grid>
          <Grid item xs={6}>
            <Typography variant="h6">Total</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="h6" align="right">
              ${total.toFixed(2)}
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

function Checkout() {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    postalCode: '',
    phone: '',
    shippingMethod: 'standard',
    shippingCost: 5.99,
    paymentMethod: 'card',
    cardNumber: '',
    cardExpiry: '',
    cardCvv: '',
    discountCode: '',
  });

  const steps = ['Shipping Address', 'Delivery Method', 'Payment', 'Review'];

  const handleNext = () => {
    if (activeStep === steps.length - 1) {
      // Place order
      navigate('/order-confirmation');
    } else {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return <AddressForm formData={formData} setFormData={setFormData} />;
      case 1:
        return <ShippingForm formData={formData} setFormData={setFormData} />;
      case 2:
        return <PaymentForm formData={formData} setFormData={setFormData} />;
      case 3:
        return (
          <>
            <Typography variant="h6" gutterBottom>
              Order Review
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle1" gutterBottom>
                  Shipping Address
                </Typography>
                <Typography variant="body2">
                  {formData.firstName} {formData.lastName}
                  <br />
                  {formData.address1}
                  {formData.address2 && <><br />{formData.address2}</>}
                  <br />
                  {formData.city}, {formData.state} {formData.postalCode}
                  <br />
                  Phone: {formData.phone}
                </Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <OrderSummary formData={formData} />
              </Grid>
            </Grid>
          </>
        );
      default:
        return <Alert severity="error">Unknown step</Alert>;
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper sx={{ p: 4 }}>
        <Typography component="h1" variant="h4" align="center" gutterBottom>
          Checkout
        </Typography>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        {getStepContent(activeStep)}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
          {activeStep !== 0 && (
            <Button onClick={handleBack} sx={{ mr: 1 }}>
              Back
            </Button>
          )}
          <Button
            variant="contained"
            onClick={handleNext}
          >
            {activeStep === steps.length - 1 ? 'Place Order' : 'Next'}
          </Button>
        </Box>
      </Paper>
    </Container>
  );
}

export default Checkout; 