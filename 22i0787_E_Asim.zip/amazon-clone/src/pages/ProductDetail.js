import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Button,
  Box,
  Rating,
  TextField,
  Snackbar,
  Alert,
  Divider,
} from '@mui/material';
import { ShoppingCart, Favorite } from '@mui/icons-material';
import Reviews from '../components/Reviews';

// Dummy product data - in a real app, this would come from an API
const product = {
  id: 1,
  name: 'Wireless Headphones',
  price: 99.99,
  image: 'https://via.placeholder.com/500',
  category: 'Electronics',
  description: 'High-quality wireless headphones with noise cancellation. Features include Bluetooth 5.0, 30-hour battery life, and comfortable ear cushions.',
  rating: 4.5,
  reviews: [
    {
      id: 1,
      user: 'John D.',
      rating: 5,
      comment: 'Great sound quality and comfortable to wear!',
      date: '2024-03-15',
    },
    {
      id: 2,
      user: 'Sarah M.',
      rating: 4,
      comment: 'Good battery life, but could be more comfortable.',
      date: '2024-03-10',
    },
  ],
  specifications: {
    'Battery Life': '30 hours',
    'Bluetooth Version': '5.0',
    'Noise Cancellation': 'Yes',
    'Weight': '250g',
    'Warranty': '1 year',
  },
};

function ProductDetail() {
  const { id } = useParams();
  const [quantity, setQuantity] = useState(1);
  const [notification, setNotification] = useState({
    open: false,
    message: '',
    type: 'success',
  });

  const handleQuantityChange = (event) => {
    const value = parseInt(event.target.value);
    if (value > 0) {
      setQuantity(value);
    }
  };

  const handleAddToCart = () => {
    // Here you would typically make an API call to add the item to cart
    setNotification({
      open: true,
      message: 'Product added to cart successfully!',
      type: 'success',
    });
  };

  const handleAddToWishlist = () => {
    // Here you would typically make an API call to add the item to wishlist
    setNotification({
      open: true,
      message: 'Product added to wishlist!',
      type: 'success',
    });
  };

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Grid container spacing={4}>
        {/* Product Image */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2}>
            <img
              src={product.image}
              alt={product.name}
              style={{ width: '100%', height: 'auto' }}
            />
          </Paper>
        </Grid>

        {/* Product Info */}
        <Grid item xs={12} md={6}>
          <Typography variant="h4" gutterBottom>
            {product.name}
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Rating value={product.rating} precision={0.5} readOnly />
            <Typography variant="body2" sx={{ ml: 1 }}>
              ({product.reviews.length} reviews)
            </Typography>
          </Box>

          <Typography variant="h5" color="primary" gutterBottom>
            ${product.price}
          </Typography>

          <Typography variant="body1" paragraph>
            {product.description}
          </Typography>

          <Box sx={{ mb: 3 }}>
            <TextField
              type="number"
              label="Quantity"
              value={quantity}
              onChange={handleQuantityChange}
              InputProps={{ inputProps: { min: 1 } }}
              sx={{ width: 100, mr: 2 }}
            />
            <Button
              variant="contained"
              color="primary"
              startIcon={<ShoppingCart />}
              onClick={handleAddToCart}
              sx={{ mr: 2 }}
            >
              Add to Cart
            </Button>
            <Button
              variant="outlined"
              color="primary"
              startIcon={<Favorite />}
              onClick={handleAddToWishlist}
            >
              Add to Wishlist
            </Button>
          </Box>

          {/* Specifications */}
          <Paper elevation={1} sx={{ p: 2, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Specifications
            </Typography>
            {Object.entries(product.specifications).map(([key, value]) => (
              <Box
                key={key}
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  borderBottom: '1px solid #eee',
                  py: 1,
                }}
              >
                <Typography variant="body2" color="text.secondary">
                  {key}
                </Typography>
                <Typography variant="body2">{value}</Typography>
              </Box>
            ))}
          </Paper>
        </Grid>

        {/* Reviews Section */}
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            Customer Reviews
          </Typography>
          {product.reviews.map((review) => (
            <Paper key={review.id} sx={{ p: 2, mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                <Rating value={review.rating} size="small" readOnly />
                <Typography variant="body2" sx={{ ml: 1 }}>
                  by {review.user}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                  {review.date}
                </Typography>
              </Box>
              <Typography variant="body1">{review.comment}</Typography>
            </Paper>
          ))}
        </Grid>
      </Grid>

      <Divider sx={{ my: 4 }} />
      
      {/* Reviews Section */}
      <Reviews productId={id} />

      <Snackbar
        open={notification.open}
        autoHideDuration={6000}
        onClose={handleCloseNotification}
      >
        <Alert
          onClose={handleCloseNotification}
          severity={notification.type}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>
    </Container>
  );
}

export default ProductDetail; 