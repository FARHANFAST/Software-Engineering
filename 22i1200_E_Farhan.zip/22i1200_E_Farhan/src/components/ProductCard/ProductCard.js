import React from 'react';
import { styled } from '@mui/material/styles';
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  IconButton,
  Box,
} from '@mui/material';
import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import { useCart } from '../../context/CartContext';

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.2s',
  '&:hover': {
    transform: 'scale(1.02)',
    boxShadow: theme.shadows[4],
  },
}));

const ProductImage = styled(CardMedia)({
  height: 200,
  objectFit: 'contain',
  padding: '16px',
  backgroundColor: '#fff',
});

const ProductTitle = styled(Typography)({
  fontSize: '1rem',
  fontWeight: 500,
  marginBottom: '8px',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
});

const ProductPrice = styled(Typography)(({ theme }) => ({
  fontSize: '1.25rem',
  fontWeight: 'bold',
  color: theme.palette.primary.main,
  marginBottom: '8px',
}));

const ProductDescription = styled(Typography)({
  fontSize: '0.875rem',
  color: '#666',
  marginBottom: '16px',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  display: '-webkit-box',
  WebkitLineClamp: 2,
  WebkitBoxOrient: 'vertical',
});

const ActionButtons = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: 'auto',
});

function ProductCard({ product }) {
  const { addToCart, addToWishlist, isInWishlist } = useCart();

  return (
    <StyledCard>
      <ProductImage
        image={product.image}
        title={product.title}
        component="img"
      />
      <CardContent>
        <ProductTitle>{product.title}</ProductTitle>
        <ProductPrice>${product.price.toFixed(2)}</ProductPrice>
        <ProductDescription>{product.description}</ProductDescription>
        <ActionButtons>
          <Button
            variant="contained"
            color="primary"
            onClick={() => addToCart(product)}
            sx={{ flex: 1, mr: 1 }}
          >
            Add to Cart
          </Button>
          <IconButton
            onClick={() => addToWishlist(product)}
            color={isInWishlist(product.id) ? 'error' : 'default'}
          >
            {isInWishlist(product.id) ? <FavoriteIcon /> : <FavoriteBorderIcon />}
          </IconButton>
        </ActionButtons>
      </CardContent>
    </StyledCard>
  );
}

export default ProductCard; 