import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Badge,
  MenuItem,
  Menu,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Divider,
  Button,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import MenuIcon from '@mui/icons-material/Menu';
import DeleteIcon from '@mui/icons-material/Delete';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { useNavigate } from 'react-router-dom';

const HeaderContainer = styled(AppBar)({
  backgroundColor: '#131921',
  position: 'static'
});

const HeaderTop = styled(Toolbar)({
  minHeight: '36px !important',
  padding: '4px 16px'
});

const Logo = styled(Typography)({
  display: 'block',
  cursor: 'pointer',
  color: 'white',
  fontWeight: 'bold',
  fontSize: '24px',
  '&:hover': {
    opacity: 0.8,
  },
  marginRight: '16px',
  '@media (max-width: 600px)': {
    display: 'none',
  },
});

const SearchContainer = styled('div')({
  position: 'relative',
  borderRadius: '4px',
  backgroundColor: '#fff',
  marginLeft: '24px',
  width: '100%',
  maxWidth: '800px',
});

const SearchInput = styled('input')({
  width: '100%',
  padding: '8px 8px 8px 40px',
  border: 'none',
  borderRadius: '4px',
  outline: 'none',
  fontSize: '14px',
});

const SearchIconWrapper = styled('div')({
  padding: '0 16px',
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: '#333',
});

const NavItems = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  marginLeft: 'auto',
  gap: '8px'
});

const NavItem = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  padding: '8px 12px',
  cursor: 'pointer',
  border: '1px solid transparent',
  borderRadius: '3px',
  transition: 'all 0.2s ease-in-out',
  '&:hover': {
    border: '1px solid white',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
});

const NavItemText = styled(Typography)({
  fontSize: '12px',
  color: '#fff',
  marginTop: '2px',
});

const LanguageButton = styled(Button)({
  color: 'white',
  textTransform: 'none',
  padding: '4px',
  minWidth: 'unset',
  fontSize: '14px',
});

const UserIcon = styled(IconButton)({
  color: 'white',
  padding: '4px',
  '&:hover': {
    backgroundColor: 'transparent',
  },
});

const HeaderBottom = styled(Toolbar)({
  backgroundColor: '#232f3e',
  minHeight: '36px !important',
  padding: '0 16px',
  '& .MuiButton-root': {
    color: 'white',
    textTransform: 'none',
    padding: '4px 8px',
    '&:hover': {
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
    },
  },
});

function Header() {
  const navigate = useNavigate();
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const { getCartCount, wishlistItems, removeFromWishlist } = useCart();
  const [language, setLanguage] = useState('EN');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [languageAnchorEl, setLanguageAnchorEl] = useState(null);
  const [accountAnchorEl, setAccountAnchorEl] = useState(null);
  const [wishlistAnchorEl, setWishlistAnchorEl] = useState(null);

  const handleLanguageClick = (event) => {
    setLanguageAnchorEl(event.currentTarget);
  };

  const handleLanguageClose = () => {
    setLanguageAnchorEl(null);
  };

  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
    handleLanguageClose();
  };

  const handleDrawerToggle = () => {
    setDrawerOpen(!drawerOpen);
  };

  const handleLogoClick = () => {
    window.location.href = '/';
  };

  const handleLogout = () => {
    logout();
    window.location.href = '/';
  };

  const handleAccountClick = (event) => {
    setAccountAnchorEl(event.currentTarget);
  };

  const handleAccountClose = () => {
    setAccountAnchorEl(null);
  };

  const handleSignIn = () => {
    window.location.href = '/signin';
  };

  const handleSignUp = () => {
    window.location.href = '/signup';
  };

  const handleCartClick = () => {
    navigate('/cart');
  };

  const handleWishlistClick = (event) => {
    setWishlistAnchorEl(event.currentTarget);
  };

  const handleWishlistClose = () => {
    setWishlistAnchorEl(null);
  };

  const handleRemoveFromWishlist = (itemId) => {
    removeFromWishlist(itemId);
  };

  return (
    <HeaderContainer>
      <HeaderTop>
        <Logo onClick={handleLogoClick} variant="h6">
          Shopfinity
        </Logo>

        <SearchContainer>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <SearchInput placeholder="Search Shopfinity" />
        </SearchContainer>

        <NavItems>
          <NavItem>
            <LanguageButton onClick={handleLanguageClick}>
              {language}
            </LanguageButton>
            <NavItemText>Language</NavItemText>
          </NavItem>

          <NavItem onClick={handleAccountClick}>
            {isAuthenticated() ? (
              <>
                <UserIcon size="small">
                  <PersonOutlineIcon />
                </UserIcon>
                <NavItemText>{user?.name}</NavItemText>
              </>
            ) : (
              <>
                <UserIcon size="small">
                  <PersonOutlineIcon />
                </UserIcon>
                <NavItemText>Sign In</NavItemText>
              </>
            )}
          </NavItem>

          <NavItem onClick={handleWishlistClick}>
            <Badge badgeContent={wishlistItems.length} color="primary">
              <FavoriteBorderIcon sx={{ color: 'white' }} />
            </Badge>
            <NavItemText>Wishlist</NavItemText>
          </NavItem>

          <NavItem onClick={handleCartClick}>
            <Badge badgeContent={getCartCount()} color="primary">
              <ShoppingCartIcon sx={{ color: 'white' }} />
            </Badge>
            <NavItemText>Cart</NavItemText>
          </NavItem>
        </NavItems>

        <Menu
          anchorEl={languageAnchorEl}
          open={Boolean(languageAnchorEl)}
          onClose={handleLanguageClose}
        >
          <MenuItem onClick={() => handleLanguageChange('EN')}>English</MenuItem>
          <MenuItem onClick={() => handleLanguageChange('ES')}>Español</MenuItem>
          <MenuItem onClick={() => handleLanguageChange('FR')}>Français</MenuItem>
        </Menu>

        <Menu
          anchorEl={accountAnchorEl}
          open={Boolean(accountAnchorEl)}
          onClose={handleAccountClose}
        >
          {isAuthenticated() ? (
            <>
              <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/account'; }}>
                Your Account
              </MenuItem>
              {isAdmin() && (
                <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/admin/dashboard'; }}>
                  Admin Dashboard
                </MenuItem>
              )}
              <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/orders'; }}>
                Your Orders
              </MenuItem>
              <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/lists'; }}>
                Your Lists
              </MenuItem>
              <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/recommendations'; }}>
                Your Recommendations
              </MenuItem>
              <Divider />
              <MenuItem onClick={() => { handleAccountClose(); window.location.href = '/help'; }}>
                Help & Settings
              </MenuItem>
              <MenuItem onClick={handleLogout}>
                Sign Out
              </MenuItem>
            </>
          ) : (
            <>
              <MenuItem onClick={handleSignIn}>
                Sign In
              </MenuItem>
              <MenuItem onClick={handleSignUp}>
                New Customer? Start here
              </MenuItem>
            </>
          )}
        </Menu>

        <Menu
          anchorEl={wishlistAnchorEl}
          open={Boolean(wishlistAnchorEl)}
          onClose={handleWishlistClose}
        >
          {wishlistItems.length === 0 ? (
            <MenuItem disabled>Your wishlist is empty</MenuItem>
          ) : (
            wishlistItems.map(item => (
              <MenuItem key={item.id}>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 1,
                  width: '100%',
                  justifyContent: 'space-between'
                }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <img src={item.image} alt={item.title} style={{ width: 40, height: 40 }} />
                    <Typography>{item.title}</Typography>
                  </Box>
                  <IconButton
                    size="small"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveFromWishlist(item.id);
                    }}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              </MenuItem>
            ))
          )}
        </Menu>
      </HeaderTop>

      <HeaderBottom>
        <Button
          onClick={handleDrawerToggle}
          startIcon={<MenuIcon />}
        >
          All
        </Button>
        <Button>Today's Deals</Button>
        <Button>Customer Service</Button>
        <Button>Registry</Button>
        <Button>Gift Cards</Button>
        <Button>Sell</Button>
      </HeaderBottom>

      <Drawer
        anchor="left"
        open={drawerOpen}
        onClose={handleDrawerToggle}
      >
        <List sx={{ width: 300, bgcolor: 'background.paper' }}>
          <ListItem>
            <ListItemText primary="Help & Settings" />
          </ListItem>
          <Divider />
          <ListItem>
            <ListItemText primary="Your Account" />
          </ListItem>
        </List>
      </Drawer>
    </HeaderContainer>
  );
}

export default Header; 