import React from 'react';
import { IconButton } from '@mui/material';
import { styled } from '@mui/material/styles';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate } from 'react-router-dom';

const StyledBackButton = styled(IconButton)(({ theme }) => ({
  position: 'absolute',
  left: theme.spacing(2),
  top: theme.spacing(2),
  backgroundColor: 'white',
  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  '&:hover': {
    backgroundColor: 'rgba(0, 0, 0, 0.04)',
  },
  '@media (max-width: 600px)': {
    left: theme.spacing(1),
    top: theme.spacing(1),
  },
  marginTop: '64px',
}));

function BackButton() {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <StyledBackButton onClick={handleBack} aria-label="back">
      <ArrowBackIcon />
    </StyledBackButton>
  );
}

export default BackButton; 