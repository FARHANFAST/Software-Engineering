import React from 'react';
import { styled } from '@mui/material/styles';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  IconButton,
  TextField,
  Divider,
  Grid,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

const CartContainer = styled(Container)(({ theme }) => ({
  padding: theme.spacing(4),
  marginTop: theme.spacing(4),
}));

const CartItem = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  marginBottom: theme.spacing(2),
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(2),
}));

const ItemImage = styled('img')({
  width: 120,
  height: 120,
  objectFit: 'contain',
});

const ItemDetails = styled(Box)({
  flex: 1,
});

const QuantityControls = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  gap: 8,
});

const Price = styled(Typography)(({ theme }) => ({
  fontWeight: 'bold',
  fontSize: '1.2rem',
  color: theme.palette.primary.main,
}));

const Subtotal = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  marginTop: theme.spacing(2),
}));

function Cart() {
  const { cartItems, removeFromCart, updateCartItemQuantity, getCartCount } = useCart();
  const navigate = useNavigate();

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const handleQuantityChange = (itemId, newQuantity) => {
    updateCartItemQuantity(itemId, newQuantity);
  };

  const handleCheckout = () => {
    // Navigate to checkout page (to be implemented)
    navigate('/checkout');
  };

  if (getCartCount() === 0) {
    return (
      <CartContainer>
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" gutterBottom>
            Your cart is empty
          </Typography>
          <Button
            variant="contained"
            color="primary"
            onClick={() => navigate('/')}
          >
            Continue Shopping
          </Button>
        </Paper>
      </CartContainer>
    );
  }

  return (
    <CartContainer>
      <Typography variant="h4" gutterBottom>
        Shopping Cart
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          {cartItems.map((item) => (
            <CartItem key={item.id} elevation={2}>
              <ItemImage src={item.image} alt={item.title} />
              <ItemDetails>
                <Typography variant="h6" gutterBottom>
                  {item.title}
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {item.description}
                </Typography>
                <Price>${item.price.toFixed(2)}</Price>
              </ItemDetails>
              <QuantityControls>
                <IconButton
                  size="small"
                  onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                >
                  <RemoveIcon />
                </IconButton>
                <TextField
                  value={item.quantity}
                  type="number"
                  size="small"
                  sx={{ width: 60 }}
                  inputProps={{ min: 1 }}
                  onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                />
                <IconButton
                  size="small"
                  onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                >
                  <AddIcon />
                </IconButton>
                <IconButton
                  color="error"
                  onClick={() => removeFromCart(item.id)}
                >
                  <DeleteIcon />
                </IconButton>
              </QuantityControls>
            </CartItem>
          ))}
        </Grid>

        <Grid item xs={12} md={4}>
          <Subtotal elevation={2}>
            <Typography variant="h6" gutterBottom>
              Order Summary
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography>Subtotal ({getCartCount()} items)</Typography>
              <Typography>${calculateSubtotal().toFixed(2)}</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Typography>Shipping</Typography>
              <Typography>Free</Typography>
            </Box>
            <Divider sx={{ my: 2 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
              <Typography variant="h6">Total</Typography>
              <Typography variant="h6">${calculateSubtotal().toFixed(2)}</Typography>
            </Box>
            <Button
              variant="contained"
              color="primary"
              fullWidth
              onClick={handleCheckout}
            >
              Proceed to Checkout
            </Button>
          </Subtotal>
        </Grid>
      </Grid>
    </CartContainer>
  );
}

export default Cart; 