import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%',
  maxWidth: '400px',
  margin: '0 auto',
}));

const Form = styled('form')(({ theme }) => ({
  width: '100%',
  marginTop: theme.spacing(1),
}));

const SubmitButton = styled(Button)(({ theme }) => ({
  margin: theme.spacing(3, 0, 2),
}));

function SignIn() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    role: 'user',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    // For demo purposes, we'll use these credentials
    const demoCredentials = {
      admin: {
        email: 'admin@shopfinity.com',
        password: 'admin123',
        role: 'admin'
      },
      user: {
        email: 'user@shopfinity.com',
        password: 'user123',
        role: 'user'
      }
    };

    const credentials = formData.role === 'admin' ? demoCredentials.admin : demoCredentials.user;

    if (formData.email === credentials.email && formData.password === credentials.password) {
      login({
        email: formData.email,
        role: formData.role,
        name: formData.role === 'admin' ? 'Admin User' : 'Regular User'
      });

      if (formData.role === 'admin') {
        navigate('/admin/dashboard');
      } else {
        navigate('/');
      }
    } else {
      setError('Invalid email or password');
    }
  };

  const handleContainerClick = (e) => {
    // Only navigate back if clicking outside the form
    if (e.target === e.currentTarget) {
      navigate(-1);
    }
  };

  return (
    <Container 
      component="main" 
      maxWidth="xs" 
      onClick={handleContainerClick}
      sx={{ 
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        cursor: 'pointer',
        pt: 8,
      }}
    >
      <StyledPaper elevation={3} onClick={(e) => e.stopPropagation()}>
        <Typography component="h1" variant="h5">
          Sign In
        </Typography>
        {error && (
          <Alert severity="error" sx={{ mt: 2, width: '100%' }}>
            {error}
          </Alert>
        )}
        <Form onSubmit={handleSubmit}>
          <FormControl fullWidth margin="normal">
            <InputLabel>Role</InputLabel>
            <Select
              name="role"
              value={formData.role}
              onChange={handleChange}
              label="Role"
            >
              <MenuItem value="user">User</MenuItem>
              <MenuItem value="admin">Admin</MenuItem>
            </Select>
          </FormControl>

          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email Address"
            name="email"
            autoComplete="email"
            autoFocus
            value={formData.email}
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={formData.password}
            onChange={handleChange}
          />
          <SubmitButton
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
          >
            Sign In
          </SubmitButton>
        </Form>
        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <Typography variant="body2">
            Don't have an account?{' '}
            <Button
              color="primary"
              onClick={() => navigate('/signup')}
            >
              Sign Up
            </Button>
          </Typography>
        </Box>
      </StyledPaper>
    </Container>
  );
}

export default SignIn; 