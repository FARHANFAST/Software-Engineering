import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Paper, 
  Typography, 
  TextField, 
  Button, 
  Link,
  Divider
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '100%',
  maxWidth: '400px',
  margin: '0 auto',
}));

const StyledForm = styled('form')(({ theme }) => ({
  width: '100%',
  marginTop: theme.spacing(1),
}));

function SignUp() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle sign up logic here
    console.log('Sign up attempt:', { name, email, password, confirmPassword });
  };

  const handleContainerClick = (e) => {
    // Only navigate back if clicking outside the form
    if (e.target === e.currentTarget) {
      navigate(-1);
    }
  };

  return (
    <Container 
      component="main" 
      maxWidth="xs" 
      onClick={handleContainerClick}
      sx={{ 
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        cursor: 'pointer',
        pt: 8,
      }}
    >
      <StyledPaper elevation={3} onClick={(e) => e.stopPropagation()}>
        <Typography component="h1" variant="h5" sx={{ mb: 2 }}>
          Create Account
        </Typography>
        <StyledForm onSubmit={handleSubmit}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="name"
            label="Full Name"
            name="name"
            autoComplete="name"
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email Address"
            name="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="new-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="confirmPassword"
            label="Confirm Password"
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2, backgroundColor: '#f0c14b', '&:hover': { backgroundColor: '#f4d078' } }}
          >
            Create Account
          </Button>
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="body2" sx={{ mb: 1 }}>
              By creating an account, you agree to Shopfinity's{' '}
              <Link href="#" underline="hover">
                Conditions of Use
              </Link>{' '}
              and{' '}
              <Link href="#" underline="hover">
                Privacy Notice
              </Link>
            </Typography>
            <Divider sx={{ my: 2 }}>Already have an account?</Divider>
            <Button
              fullWidth
              variant="outlined"
              onClick={() => navigate('/signin')}
              sx={{ mt: 2, borderColor: '#adb1b8', color: '#111' }}
            >
              Sign in to your account
            </Button>
          </Box>
        </StyledForm>
      </StyledPaper>
    </Container>
  );
}

export default SignUp; 