import React from 'react';
import { Container, Grid, Typography } from '@mui/material';
import ProductCard from '../components/ProductCard/ProductCard';

// Sample product data
const products = [
  {
    id: 1,
    title: "Wireless Headphones",
    description: "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
    price: 99.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop"
  },
  {
    id: 2,
    title: "Smart Watch",
    description: "Fitness tracking smartwatch with heart rate monitoring and GPS.",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500&h=500&fit=crop"
  },
  {
    id: 3,
    title: "Laptop Backpack",
    description: "Durable laptop backpack with multiple compartments and water-resistant material.",
    price: 49.99,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop"
  },
  {
    id: 4,
    title: "Coffee Maker",
    description: "Programmable coffee maker with 12-cup capacity and built-in grinder.",
    price: 79.99,
    image: "https://images.unsplash.com/photo-1517661931470-4a47f1c9ec9e?w=500&h=500&fit=crop"
  }
];

function Home() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Featured Products
      </Typography>
      <Grid container spacing={4}>
        {products.map((product) => (
          <Grid item key={product.id} xs={12} sm={6} md={3}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

export default Home; 